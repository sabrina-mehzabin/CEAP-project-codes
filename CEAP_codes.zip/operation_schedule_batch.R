# =================================================================
# Script B — Batch .mgt editor: HAY-only 70/30 split + rotations
# (aligned to Script A: year-end MGT_OP = 0 inside each 1-year schedule)
# =================================================================

suppressPackageStartupMessages({
  library(stringr)
  library(readr)
  library(dplyr)
})

# ---------- USER INPUT ----------
input_dir        <- "~/copy_calib/calibfolder1"          # folder of .mgt files
hru_file         <- "~/copy_calib/calibfolder1/HAY.csv"  # must have SUBBASIN, HRU, LANDUSE
# Use the soil-P mapping file created in the previous step
mapping_csv      <- "~/copy_calib/calibfolder1/soilP_init_mapping_for_mgt.csv"  # includes 70/30 split
explicit_map_csv <- NULL   # let the script auto-generate the 70/30 split


TOTAL_COLS       <- 100   # total fixed width of op lines (adjust if needed)

# Rotation recipes per cohort (edit freely)
rotation_for_hay_cohort  <- c(hay = 4, corn = 2, hay = 2)
rotation_for_corn_cohort <- c(corn = 6, hay = 2)

# Header edits (above schedule) per cohort
header_edits_hay  <- list(FILTERW = 0, USLE_P = 1.0)
header_edits_corn <- list(FILTERW = 0, USLE_P = 1.0)

set.seed(123)     # reproducible 70/30 split

# ---------- Fixed-width core ----------
fixed_line <- function(specs, total_cols = TOTAL_COLS) {
  buf <- strrep(" ", total_cols)
  for (i in seq_len(nrow(specs))) {
    s <- sprintf(specs$fmt[i], specs$val[i])
    w <- specs$width[i]
    if (nchar(s) < w) s <- sprintf(paste0("%", w, "s"), s)
    if (nchar(s) > w) s <- substr(s, 1, w)
    substr(buf, specs$col[i], specs$col[i] + w - 1) <- s
  }
  buf
}

# MONTH 2–3 (i2), DAY 5–6 (i2), HUSC 8–15 (f8.3), MGT_OP 17–18 (i2)
common_prefix_specs <- function(month, day, mgt_op, husc = 0) {
  data.frame(
    name  = c("MONTH","DAY","HUSC","MGT_OP"),
    col   = c(2,       5,     8,     17),
    width = c(2,       2,     8,      2),
    fmt   = c("%02d","%02d","%8.3f","%2d"),
    val   = c(month,   day,   husc,   mgt_op),
    stringsAsFactors = FALSE
  )
}

# ---------- Operation builders ----------
build_tillage <- function(month, day, TILL_ID, husc = 0) {
  spec <- common_prefix_specs(month, day, 6, husc)
  spec2 <- rbind(spec, data.frame(name="TILL_ID", col=20, width=4, fmt="%4d", val=TILL_ID))
  fixed_line(spec2)
}
build_fertilizer <- function(month, day, FERT_ID, FERT_KG, FRT_SURFACE, husc = 0) {
  if (is.character(FERT_KG)) FERT_KG <- as.numeric(gsub(",", "", FERT_KG))
  spec <- common_prefix_specs(month, day, 3, husc)
  spec2 <- rbind(
    spec,
    data.frame(name="FERT_ID",     col=20, width=4,  fmt="%4d",     val=FERT_ID),
    data.frame(name="FERT_KG",     col=32, width=12, fmt="%12.5f",  val=FERT_KG),
    data.frame(name="FRT_SURFACE", col=45, width=6,  fmt="%6.2f",   val=FRT_SURFACE)
  )
  fixed_line(spec2)
}
build_planting <- function(month, day, PLANT_ID, HEAT_UNITS, husc = 0) {
  spec <- common_prefix_specs(month, day, 1, husc)
  spec2 <- rbind(
    spec,
    data.frame(name="PLANT_ID",   col=20, width=4,  fmt="%4d",     val=PLANT_ID),
    data.frame(name="HEAT_UNITS", col=32, width=12, fmt="%12.5f",  val=HEAT_UNITS)
  )
  fixed_line(spec2)
}
build_harvest <- function(month, day, HARVEFF = 1.0, husc = 0) {
  spec <- common_prefix_specs(month, day, 7, husc)
  spec2 <- rbind(spec, data.frame(name="HARVEFF", col=32, width=12, fmt="%12.5f", val=HARVEFF))
  fixed_line(spec2)
}
build_kill <- function(month, day, husc = 0) {
  spec <- common_prefix_specs(month, day, 8, husc)
  fixed_line(spec)
}

# Year-end marker for Script A logic: MGT_OP = 0
build_year_end <- function(month = 12, day = 31, husc = 0) {
  spec <- common_prefix_specs(month, day, 0, husc)
  fixed_line(spec)
}

# ---------- One-year schedules (include the year-end = 0 line INSIDE) ----------
corn_schedule_one_year <- function() {
  c(
    build_tillage   (5, 10, TILL_ID=61),
    build_fertilizer(5, 15, FERT_ID=54, FERT_KG="112.085",  FRT_SURFACE=0.00),
    build_planting  (5, 15, PLANT_ID=4, HEAT_UNITS=1800.0),
    build_fertilizer(7, 10, FERT_ID=54, FERT_KG="266.302",  FRT_SURFACE=0.20),
    build_harvest   (10, 1, HARVEFF=1.0),
    build_kill      (10, 1),
    build_fertilizer(10,10, FERT_ID=53, FERT_KG="2806.200", FRT_SURFACE=1.00),
    build_tillage   (10,15, TILL_ID=57),
    build_year_end  (12, 31, husc = 0)  # <-- MGT_OP = 0
  )
}
hay_schedule_one_year <- function() {
  c(
    build_planting  (5, 1,  PLANT_ID=4, HEAT_UNITS=1200.0),
    build_fertilizer(5, 2,  FERT_ID=54, FERT_KG="168.127",  FRT_SURFACE=0.20),
    build_harvest   (6, 1,  HARVEFF=1.0),
    build_harvest   (7, 15, HARVEFF=1.0),
    build_fertilizer(7, 16, FERT_ID=53, FERT_KG="842.0",  FRT_SURFACE=1.00),
    build_harvest   (8, 30, HARVEFF=1.0),
    build_fertilizer(9, 1,  FERT_ID=53, FERT_KG="842.0",  FRT_SURFACE=1.00),
    build_year_end  (12, 31, husc = 0)  # <-- MGT_OP = 0
  )
}

# ---------- Rotation builder (NO extra year-end added here) ----------
.schedule_map <- list(hay = hay_schedule_one_year, corn = corn_schedule_one_year)
build_rotation_schedule <- function(rotation_vec) {
  stopifnot(length(rotation_vec) > 0, !is.null(names(rotation_vec)))
  lines <- character(0); total_years <- 0L
  for (k in seq_along(rotation_vec)) {
    crop <- names(rotation_vec)[k]; yrs <- as.integer(rotation_vec[[k]])
    if (!crop %in% names(.schedule_map)) stop("Unknown crop key: ", crop)
    one_year <- .schedule_map[[crop]]()
    for (i in seq_len(yrs)) lines <- c(lines, one_year)     # <-- no extra 0/17 here
    total_years <- total_years + yrs
  }
  attr(lines, "nrot") <- total_years
  lines
}

# ---------- Header & schedule helpers ----------
# Robust updater, limited to lines ABOVE "Operation Schedule:"
# Replace the number immediately before "| KEY"
mgt_update_header_by_label <- function(lines, header_updates = list()) {
  if (!length(header_updates)) return(lines)
  ops_line <- grep("^\\s*Operation\\s+Schedule:", lines)
  end_ix   <- if (length(ops_line)) ops_line[1] - 1 else length(lines)
  
  for (nm in names(header_updates)) {
    ix <- grep(paste0("\\|\\s*", nm, "\\b"), lines[seq_len(end_ix)], perl = TRUE)
    if (!length(ix)) next
    v  <- header_updates[[nm]]
    tgt <- ix[1]
    lines[tgt] <- sub(
      pattern = "([-+]?\\d*\\.?\\d+)(?=\\s*\\|\\s*[A-Za-z0-9_]+\\b)",
      replacement = as.character(v),
      x = lines[tgt],
      perl = TRUE
    )
  }
  lines
}

# (2) Stricter NROT matcher
mgt_set_nrot <- function(lines, nrot) {
  ix <- grep("\\|\\s*NROT\\b", lines, perl = TRUE)
  if (!length(ix)) stop("NROT line not found.")
  tgt <- ix[1]
  lines[tgt] <- sub("^\\s*[-+]?[0-9]*\\.?\\d+", as.character(as.integer(nrot)), lines[tgt])
  lines
}

# EOF-safe replacement (prevents NA line)
replace_operation_schedule <- function(lines, new_schedule_lines) {
  start <- grep("^\\s*Operation\\s+Schedule:", lines)
  if (!length(start)) stop("'Operation Schedule:' line not found.")
  start <- start[1]
  after <- start + 1L
  while (after <= length(lines) &&
         nzchar(trimws(lines[after])) &&
         !grepl("^\\s*[A-Za-z].*:\\s*$", lines[after])) {
    after <- after + 1L
  }
  if (after > length(lines)) {
    c(lines[1:start], new_schedule_lines)
  } else {
    c(lines[1:start], new_schedule_lines, lines[after:length(lines)])
  }
}

# ---------- Validation ----------
.parse_field <- function(line, start, end) as.integer(gsub("\\s+", "", substr(line, start, end)))

validate_ops <- function(op_lines, total_cols = TOTAL_COLS) {
  ok <- TRUE; problems <- list()
  for (i in seq_along(op_lines)) {
    L <- op_lines[[i]]
    if (nchar(L, "bytes") != total_cols) { ok <- FALSE; problems[[length(problems)+1]] <- paste0("Line ", i, ": width=", nchar(L, "bytes")); next }
    mm <- .parse_field(L, 2, 3); dd <- .parse_field(L, 5, 6)
    if (is.na(mm) || mm < 1 || mm > 12) { ok <- FALSE; problems[[length(problems)+1]] <- paste0("Line ", i, ": bad MONTH=", mm) }
    if (is.na(dd) || dd < 1 || dd > 31) { ok <- FALSE; problems[[length(problems)+1]] <- paste0("Line ", i, ": bad DAY=", dd) }
    op <- .parse_field(L, 17, 18)
    if (is.na(op) || !(op %in% c(0,1,3,6,7,8,17))) { ok <- FALSE; problems[[length(problems)+1]] <- paste0("Line ", i, ": bad MGT_OP=", op) }  # allow 0 (year-end)
  }
  list(ok = ok, problems = problems)
}

# Count year-ends as MGT_OP == 0 (for NROT cross-check)
count_year_ends <- function(op_lines) sum(vapply(op_lines, function(L) .parse_field(L,17,18)==0L, logical(1)))

# ---------- Writers ----------
# (1) Backup before write; write only if changed
update_mgt_file <- function(mgt_path, schedule_lines, nrot, header_updates = list()) {
  chk <- validate_ops(schedule_lines, total_cols = TOTAL_COLS)
  if (!chk$ok) stop(paste(c("Validation failed:", unlist(chk$problems)), collapse = "\n"))
  if (count_year_ends(schedule_lines) != nrot) stop("NROT mismatch between rotation and year-end (0) count.")
  
  old <- readLines(mgt_path, warn = FALSE)
  new <- old
  new <- mgt_update_header_by_label(new, header_updates)
  new <- mgt_set_nrot(new, nrot)
  new <- replace_operation_schedule(new, schedule_lines)
  
  if (!identical(old, new)) {
    bak <- paste0(mgt_path, ".bak")
    writeLines(old, bak, useBytes = TRUE)
    writeLines(new, mgt_path, useBytes = TRUE)
  }
  invisible(TRUE)
}

update_mgt_file_with_rotation <- function(mgt_path, rotation_vec, header_updates = list()) {
  sched <- build_rotation_schedule(rotation_vec)
  nrot  <- attr(sched, "nrot")
  update_mgt_file(mgt_path, sched, nrot, header_updates)
}

# ---------- Build/Load 70/30 map (HAY only) ----------
hru_data <- read_csv(hru_file, show_col_types = FALSE) %>%
  mutate(LANDUSE = toupper(trimws(LANDUSE)))
if (!all(c("SUBBASIN","HRU","LANDUSE") %in% names(hru_data))) stop("hru_file must contain SUBBASIN, HRU, LANDUSE")

if (!is.null(explicit_map_csv) && file.exists(explicit_map_csv)) {
  map <- read_csv(explicit_map_csv, show_col_types = FALSE) %>%
    mutate(TARGET = tolower(trimws(TARGET)))
  stopifnot(all(c("SUBBASIN","HRU","TARGET") %in% names(map)))
} else {
  hay_pool <- filter(hru_data, LANDUSE == "HAY")
  if (nrow(hay_pool) == 0) stop("No HAY HRUs found.")
  n_hay <- nrow(hay_pool)
  n70   <- max(1L, min(n_hay - 1L, floor(0.70 * n_hay)))
  idx   <- sample(n_hay, size = n70)
  map <- bind_rows(
    hay_pool[idx,  c("SUBBASIN","HRU")] %>% mutate(TARGET = "hay"),
    hay_pool[-idx, c("SUBBASIN","HRU")] %>% mutate(TARGET = "corn")
  )
  if (!is.null(explicit_map_csv)) {
    write_csv(map, explicit_map_csv)
  } else {
    out_map_csv <- file.path(dirname(hru_file), "hru_target_map_autosplit.csv")
    write_csv(map, out_map_csv)
    message("70/30 split saved to: ", out_map_csv)
  }
}
hru_lut <- hru_data %>% left_join(map, by = c("SUBBASIN","HRU"))

# ---------- Filename parser (5-digit SUB + 4–5-digit HRU) ----------
parse_sb_hru <- function(path) {
  base <- basename(path)
  m <- regexec("^(\\d{5})(\\d{4,5})\\.mgt$", base, perl = TRUE)
  parts <- regmatches(base, m)[[1]]
  if (length(parts) == 3) list(sb = as.integer(parts[2]), hru = as.integer(parts[3])) else NULL
}

# ---------- Batch run on HAY-split only ----------
# (3) Skip hidden files
mgt_files  <- list.files(input_dir, pattern = "^[^.].*\\.mgt$", full.names = TRUE)

count_hay <- 0L; count_corn <- 0L; count_skip <- 0L

for (fp in mgt_files) {
  ids <- parse_sb_hru(fp)
  if (is.null(ids)) { message("Skip (name pattern): ", basename(fp)); count_skip <- count_skip + 1L; next }
  
  row <- hru_lut %>% filter(SUBBASIN == ids$sb, HRU == ids$hru) %>% slice_head(n = 1)
  if (nrow(row) == 0L || is.na(row$TARGET)) { message("Skip (no target): ", basename(fp)); count_skip <- count_skip + 1L; next }
  
  if (row$TARGET[[1]] == "hay") {
    update_mgt_file_with_rotation(fp, rotation_for_hay_cohort,  header_edits_hay)
    message("OK (HAY):   ", basename(fp))   # (5) per-file log
    count_hay  <- count_hay  + 1L
  } else if (row$TARGET[[1]] == "corn") {
    update_mgt_file_with_rotation(fp, rotation_for_corn_cohort, header_edits_corn)
    message("OK (CORN):  ", basename(fp))   # (5) per-file log
    count_corn <- count_corn + 1L
  } else {
    message("Skip (other): ", basename(fp)) # (5) per-file log
    count_skip <- count_skip + 1L
  }
}

cat("\nBatch summary:",
    "\n  HAY cohort edited:    ", count_hay,
    "\n  CORN cohort edited:   ", count_corn,
    "\n  Skipped (non-HAY/NA): ", count_skip,
    "\n  Total scanned:        ", length(mgt_files), "\n")


################
###SWAT run###

##############################################################################
pacman::p_load(SWATmodel,dplyr,EcoHydRology,base,topmodel,utils, lubridate,stringr,diffobj,tidyr,rnoaa,readr,ggplot2)

run_swat <- function(swat_exe  = "~/new_swat/rev688_64rel_linux",
                     work_dir  = "~/copy_calib/calibfolder1") {
  
  swat_exe <- path.expand(swat_exe)
  work_dir <- path.expand(work_dir)
  
  if (!file.exists(swat_exe)) stop("SWAT executable not found: ", swat_exe)
  if (!dir.exists(work_dir))  stop("Working dir not found: ", work_dir)
  
  setwd(work_dir)
  
  message("Cleaning old output files …")
  old_out <- list.files(pattern = "output\\.")
  if (length(old_out)) file.remove(old_out)
  
  message("Running SWAT …")
  system(shQuote(swat_exe), intern = FALSE)
  
  new_out <- list.files(pattern = "output\\.")
  if (length(new_out)) {
    message("SWAT run completed ✔")
    return(new_out)
  } else stop("SWAT produced no output files.")
}

# ── run it ───────────────────────────────────────────────────────────────────
output_files <- run_swat()
cat("Generated output files:\n"); print(output_files)




#############
# Load necessary libraries
library(dplyr)
library(ggplot2)
library(EcoHydRology)  # For NSeff function
myhomedir = Sys.getenv("HOME")
basedir = myhomedir
codedir = paste0(basedir,"/swat_LOC/R" )

# Set working directory and load SWAT outputs
setwd("~/copy_calib/calibfolder1")  # Update with new SWAT run folder
source(paste0(codedir, "/readSWAT_3.R"))
save(readSWAT,file="readSWAT.R")

flowgage_id="04282650" #Little Otter Creek at Ferrisburg, VT.
flowgage=get_usgs_gage(flowgage_id,begin_date = "2019-01-01",end_date= "2023-12-31")
#flowgage$flowdata$Qmm=(flowgage$flowdata$flow)/(flowgage$area*1000)#mm
flowgage$flowdata$flowcms = flowgage$flowdata$flow/24/3600 #m3/s

out_Calib_Tflo <- readSWAT("rch")
output_rch_3 = out_Calib_Tflo[out_Calib_Tflo$RCH==3,]
output_observed_merged <- base::merge(flowgage$flowdata,output_rch_3, all=F)


observed_data <- read.csv("Total_P.csv")

# Assuming your date is in the format "mm/dd/yy"
# First, convert the date to the Date type
observed_data$Date <- as.Date(observed_data$Date, format="%m/%d/%y")

# Now format the date as a string "yyyy-mm-dd"
#observed_data$Date <- format(observed_data$Date, "%Y-%m-%d")


output_rch_3$Date <- as.Date(output_rch_3$mdate, format="%Y-%m-%d")
simulated_data <- output_rch_3

# Select the 'TOT_Pkg' column and rename it
#simulated_data <- simulated_data %>% dplyr::select(Date, Simulated_P_kg = TOT_Pkg)
simulated_data_1 <- simulated_data[, c("Date", "TOT_Pkg")]

# Merge the observed and simulated data by the 'Date' column
common_data <- merge(observed_data, simulated_data_1, by = "Date", all = FALSE)


# Define your start and end dates for the subset
start_date <- as.Date("2020-12-01")
end_date <- as.Date("2023-12-31")

# Create a logical vector for whether each row is in the duration
is_within_duration <- output_rch_3$Date >= start_date & output_rch_3$Date <= end_date

# Subset the dataframe
subset_dataframe <- output_rch_3[is_within_duration, ]


#Prepare this 'Events' csv file beforehand. It has event start date, end date, flow volume in Liter and P load in kg

Events <- read.csv("Events.csv")

# Convert the date columns to Date objects

Events$start_date <- as.Date(Events$start_date, format="%m/%d/%Y")
Events$end_date <- as.Date(Events$end_date, format="%m/%d/%Y")

output_observed_merged$date <- as.Date(output_observed_merged$date)

# Using left_join() to keep all rows from 'output_observed_merged' and get matching rows from 'modeldata'
#output_observed_merged <- left_join(output_observed_merged, modeldata[c('date', 'P')], by = 'date')


# Initialize vectors to store the aggregated flow data
simulated_flow_totals <- numeric(nrow(Events))
#observed_flow_totals <- numeric(nrow(Events))
total_precip_per_event <- numeric(nrow(Events))
total_P_per_event <- numeric(nrow(Events))

# Loop through each event and sum the flows within the event date ranges
for (i in 1:nrow(Events)) {
  # Subset daily data to the date range of the current event
  event_data <- subset(output_observed_merged, date >= Events$start_date[i] & date <= Events$end_date[i])
  
  # Sum the flows for the event period and store them in the vectors
  simulated_flow_totals[i] <- sum(event_data$FLOW_OUTcms*86400, na.rm = TRUE)#converting m3/s to m3/day
  #observed_flow_totals[i] <- sum(event_data$flowcms, na.rm = TRUE)
  # Sum the precipitation for the event and store it
  total_precip_per_event[i] <- sum(event_data$P.x, na.rm = TRUE)
  total_P_per_event[i] <- sum(event_data$TOT_Pkg, na.rm = TRUE)
}

# Add the aggregated flow totals to the Events dataframe
Events$Simulated_Flow_Total <- simulated_flow_totals
#Events$Observed_Flow_Total <- observed_flow_totals
# Add the total precipitation to the Events dataframe
Events$Total_Precip <- total_precip_per_event
Events$Total_P_simulated <- total_P_per_event
Events$vol <- Events$vol*0.001


NSE_P = NSeff(Events$Total_P_simulated, Events$Tot_P)

# Define font sizes
title_size <- 13
text_size <- 13 # Size for axis and legend text

ggplot(Events, aes(x = end_date)) +
  geom_point(aes(y = Total_P_simulated, color = "Simulated")) +
  geom_point(aes(y = Tot_P, color = "Observed")) +
  
  labs(x = "Time", y = "Total P (kg)", 
       title = paste0("NSE = ", round(as.numeric(NSE_P),3), sep=" ")) +
  labs(color = "") +
  theme_minimal()+
  theme(plot.title = element_text(size = title_size, hjust = 0.5),
        axis.title = element_text(size = title_size),
        axis.text = element_text(size = text_size),
        panel.border = element_rect(colour = "black", size = 1, fill = NA),
        plot.margin = margin(t = 5, r = 23, b = 5, l = 5, unit = "pt"))+ 
  scale_color_manual(values = c("Simulated" = "magenta", "Observed" = "orange"))

