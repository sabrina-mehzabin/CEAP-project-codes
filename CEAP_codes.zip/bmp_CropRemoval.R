##############################################################################
# BMP: S4_PMining (Crop-Removal / P-mining)
# - Start from P-calibrated baseline
# - Copy to BMP_scenarios/S4_PMining
# - On Hay + CornFromHay HRUs:
#     * Set ALL fertilizer (commercial + manure) FERT_KG = 0
#     * Keep harvest as-is (biomass removal exports P)
#     * Do NOT modify N separately (fertilizer contains both N & P)
##############################################################################

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(stringr)
})

## ---------- USER INPUT -----------------------------------------------------

# baselineP_dir  <- "~/copy_calib/calibfolderP_baseline"
# bmp_root       <- "~/copy_calib/BMP_scenarios_final"
# 
# scenario_name  <- "cropremoval_PMining"
# scenario_dir   <- file.path(bmp_root, scenario_name)


############ 40 years #############

# 1) Use the NEW 40-yr baseline with weather generator
baselineP_dir  <- "~/copy_calib/calibfolderP_baseline_40yrWGN"

# 2) (Recommended) keep 40-yr BMPs separate from old 8-yr BMPs
bmp_root       <- "~/copy_calib/BMP_scenarios_40yr"

scenario_name  <- "cropremoval_PMining"
scenario_dir   <- file.path(bmp_root, scenario_name)


# hay_corn_split.csv from soil P initialization
sol_dir        <- "~/copy_calib/calibfolder1"
hay_split_csv  <- file.path(sol_dir, "hay_corn_split.csv")

## ---------- PREP & COPY BASELINE -------------------------------------------

baselineP_dir <- path.expand(baselineP_dir)
scenario_dir  <- path.expand(scenario_dir)
sol_dir       <- path.expand(sol_dir)

if (!dir.exists(baselineP_dir)) stop("baselineP_dir not found: ", baselineP_dir)

dir.create(scenario_dir, recursive = TRUE, showWarnings = FALSE)

baseline_files <- list.files(baselineP_dir, full.names = TRUE, recursive = TRUE)

for (src in baseline_files) {
  rel  <- sub(paste0("^", baselineP_dir, "/"), "", src)
  dest <- file.path(scenario_dir, rel)
  dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
  file.copy(src, dest, overwrite = TRUE)
}

cat("Baseline copied into S4_PMining at:\n  ", scenario_dir, "\n")

## ---------- LOAD EXISTING 70/30 HAY–CORN SPLIT -----------------------------

if (!file.exists(hay_split_csv)) {
  stop("hay_corn_split.csv not found: ", hay_split_csv)
}

hay_split <- read_csv(hay_split_csv, show_col_types = FALSE) %>%
  mutate(HRU_ID = as.integer(HRU_ID),
         group  = trimws(group))

bmp_hru_ids <- hay_split %>%
  filter(group %in% c("Hay", "CornFromHay")) %>%
  pull(HRU_ID) %>%
  unique()

cat("HRUs targeted for S4 (Hay + CornFromHay): ", length(bmp_hru_ids), "\n")

## ---------- HELPERS ---------------------------------------------------------

parse_hru_id_from_mgt <- function(fp) {
  first_line <- readr::read_lines(fp, n_max = 1)
  hru_token  <- stringr::str_extract(first_line, "HRU:\\s*\\d+")
  if (is.na(hru_token)) return(NA_integer_)
  as.integer(stringr::str_extract(hru_token, "\\d+"))
}

parse_int <- function(line, start, end) {
  as.integer(trimws(substr(line, start, end)))
}

parse_num <- function(line, start, end) {
  as.numeric(trimws(substr(line, start, end)))
}

## ---------- CORE: Update fertilizer lines for S4 ----------------------------

update_fert_line_S4 <- function(line) {
  op <- parse_int(line, 17, 18)
  if (is.na(op) || op != 3L) return(line)   # Only modify fertilizer operations
  
  fert_kg     <- parse_num(line, 32, 43)
  frt_surface <- parse_num(line, 45, 50)
  
  # Set fertilizer amount to zero (kills both N & P)
  if (!is.na(fert_kg)) {
    fert_kg <- 0.00
  }
  
  # Write back using fixed-width format
  substr(line, 32, 43) <- sprintf("%12.5f", fert_kg)
  
  line
}

## ---------- EDIT EACH .MGT FILE --------------------------------------------

mgt_files <- list.files(scenario_dir,
                        pattern = "^[^.].*\\.mgt$",
                        full.names = TRUE,
                        recursive = TRUE)

count_edit <- 0L
count_skip <- 0L

for (fp in mgt_files) {
  hru_id <- parse_hru_id_from_mgt(fp)
  
  if (is.na(hru_id) || !(hru_id %in% bmp_hru_ids)) {
    count_skip <- count_skip + 1L
    next
  }
  
  lines <- readLines(fp, warn = FALSE)
  if (!length(lines)) next
  
  ops_line <- grep("^\\s*Operation\\s+Schedule:", lines)
  if (!length(ops_line)) next
  ops_line <- ops_line[1]
  
  # Modify op schedule lines only
  i <- ops_line + 1L
  while (i <= length(lines) &&
         nzchar(trimws(lines[i])) &&
         !grepl("^\\s*[A-Za-z].*:\\s*$", lines[i])) {
    
    lines[i] <- update_fert_line_S4(lines[i])
    i <- i + 1L
  }
  
  bak <- paste0(fp, ".S4_backup")
  file.copy(fp, bak, overwrite = TRUE)
  writeLines(lines, fp, useBytes = TRUE)
  
  count_edit <- count_edit + 1L
}

cat("\nS4 P-Mining Summary:",
    "\n  .mgt files edited:  ", count_edit,
    "\n  .mgt files skipped: ", count_skip,
    "\n  Scenario directory: ", scenario_dir, "\n\n")


##############################################################################
# --- Run SWAT for S4 (Crop-Removal / P-mining) and plot event-based TP -----
##############################################################################

# Load packages you already use in other scripts
pacman::p_load(
  SWATmodel, dplyr, EcoHydRology, base, topmodel, utils,
  lubridate, stringr, diffobj, tidyr, rnoaa, readr, ggplot2
)

# 1) Function to run SWAT in the S4 scenario folder
run_swat_S4 <- function(swat_exe  = "~/new_swat/rev688_64rel_linux",
                        work_dir  = scenario_dir) {
  
  swat_exe <- path.expand(swat_exe)
  work_dir <- path.expand(work_dir)
  
  if (!file.exists(swat_exe)) stop("SWAT executable not found: ", swat_exe)
  if (!dir.exists(work_dir))  stop("Working dir not found: ", work_dir)
  
  setwd(work_dir)
  
  message("Cleaning old output files …")
  old_out <- list.files(pattern = "output\\.")
  if (length(old_out)) file.remove(old_out)
  
  message("Running SWAT for S4 Crop-Removal (P-mining) …")
  system(shQuote(swat_exe), intern = FALSE)
  
  new_out <- list.files(pattern = "output\\.")
  if (length(new_out)) {
    message("SWAT run completed ✔")
    return(new_out)
  } else {
    stop("SWAT produced no output files in scenario_dir.")
  }
}

# ---- actually run it ----
output_files_S4 <- run_swat_S4()
cat("Generated output files in S4 scenario:\n"); print(output_files_S4)


##############################################################################
# 2) Read SWAT output, aggregate event-based TP, and make time-series plot   #
##############################################################################

# load your readSWAT helper
myhomedir <- Sys.getenv("HOME")
basedir   <- myhomedir
codedir   <- file.path(basedir, "swat_LOC", "R")

source(file.path(codedir, "readSWAT_3.R"))
save(readSWAT, file = "readSWAT.R")

# Read reach outputs from S4 run
load("readSWAT.R")
outdata  <- readSWAT("rch", ".")         # uses current working dir (scenario_dir)
rch_data <- subset(outdata, RCH == 3)    # your calibration reach
rch_data$Date <- rch_data$mdate

# Read event definitions + observed TP (same Events.csv as baseline)
Events <- read.csv("Events.csv")
Events$start_date <- as.Date(Events$start_date, "%m/%d/%Y")
Events$end_date   <- as.Date(Events$end_date,   "%m/%d/%Y")

# Aggregate simulated TP per event (kg) using TOT_Pkg
sim_P <- numeric(nrow(Events))
for (i in seq_len(nrow(Events))) {
  ev <- subset(rch_data,
               Date >= Events$start_date[i] &
                 Date <= Events$end_date[i])
  sim_P[i] <- sum(ev$TOT_Pkg, na.rm = TRUE)
}
Events$Total_P_simulated_S4 <- sim_P

# If your Events.csv already has observed TP column named Tot_P,
# we can reuse it directly for plotting.

##############################################################################
# 3) Plot Observed vs Simulated event-based TP through time                  #
##############################################################################

ggplot(Events, aes(x = end_date)) +
  geom_line(aes(y = Total_P_simulated_S4, color = "Simulated (S4)"),
            size = 2, alpha = 0.9) +
  geom_line(aes(y = Tot_P, color = "Observed"),
            size = 2, alpha = 0.9) +
  labs(
    x = "Time",
    y = "Total P (kg)",
    color = ""
  ) +
  scale_color_manual(
    values = c("Simulated (S4)" = "magenta", "Observed" = "orange")
  ) +
  theme_minimal(base_size = 15) +
  theme(
    plot.title  = element_text(size = 16, hjust = 0.5),
    axis.title  = element_text(size = 15),
    axis.text   = element_text(size = 13),
    panel.border = element_rect(color = "black", fill = NA, size = 1),
    plot.margin = margin(t = 5, r = 25, b = 5, l = 5, unit = "pt")
  )

