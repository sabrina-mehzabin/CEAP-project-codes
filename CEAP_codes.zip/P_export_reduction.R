
###################
##### BMPs (for Paper 2): P export reduction and negative soil P balance #####
###################

library(dplyr)
library(tidyr)
library(purrr)
library(lubridate)

#### prepare snu_joined for any run directory###

prep_snu_joined <- function(run_dir) {
  # Read clean SWAT outputs
  hru <- readSWAT("hru", run_dir)
  snu <- readSWAT("snu", run_dir)
  
  # Make GIS names match and join land use + area into SNU
  snu <- snu %>%
    rename(GIS = GISnum)
  
  hru_keep <- hru %>%
    select(mdate, HRU, LULC, AREAkm2, GIS)
  
  snu_joined <- snu %>%
    left_join(hru_keep, by = c("mdate", "GIS")) %>%
    mutate(
      mdate      = as.Date(mdate),
      year       = year(mdate),
      soilP_kg_ha = SOL_P + ORG_P             # legacy soil P per ha
    )
  
  list(
    hru        = hru,
    snu_joined = snu_joined
  )
}

#### Hay HRU soil-P stock table (per HRU, year-end, kg/ha) ####

hay_soilP_table <- function(run_dir) {
  obj <- prep_snu_joined(run_dir)
  snu_joined <- obj$snu_joined
  
  # Only hay HRUs
  hay_snu <- snu_joined %>%
    filter(LULC == "ORCD")
  
  # Year-end soil P for each HRU and year
  hay_year_end <- hay_snu %>%
    group_by(HRU, year) %>%
    filter(mdate == max(mdate)) %>%
    slice_tail(n = 1) %>%
    ungroup() %>%
    select(HRU, year, soilP_kg_ha)
  
  # Wide table: rows = HRU, cols = years
  hay_legacy_table <- hay_year_end %>%
    pivot_wider(
      names_from  = year,
      values_from = soilP_kg_ha
    ) %>%
    arrange(HRU)
  
  hay_legacy_table
}

#### Annual hay HRU P loss (kg/ha/yr) ####

hay_P_loss_annual <- function(run_dir) {
  obj <- prep_snu_joined(run_dir)
  hru <- obj$hru
  
  hru_hay <- hru %>%
    filter(LULC == "ORCD") %>%
    mutate(
      mdate = as.Date(mdate),
      year  = year(mdate),
      P_loss_day_kg_ha =
        coalesce(SOLPkg_per_ha, 0) +
        coalesce(SEDPkg_per_ha, 0) +
        coalesce(P_GWkg_per_ha, 0)
    )
  
  hru_hay %>%
    group_by(HRU, year) %>%
    summarise(
      P_loss_kg_ha_yr = sum(P_loss_day_kg_ha, na.rm = TRUE),
      .groups = "drop"
    )
}

#### Hay HRU P mass balance (kg/ha/yr) ####

hay_P_balance <- function(run_dir) {
  obj <- prep_snu_joined(run_dir)
  hru <- obj$hru
  snu_joined <- obj$snu_joined
  
  # ---- Inputs & outputs from HRU output ----
  hru_hay <- hru %>%
    filter(LULC == "ORCD") %>%
    mutate(
      mdate = as.Date(mdate),
      year  = year(mdate),
      P_in_day  =
        coalesce(P_APPkg_per_ha, 0) +
        coalesce(PAUTOkg_per_ha, 0) +
        coalesce(PGRZkg_per_ha, 0) +
        coalesce(PCFRTkg_per_ha, 0),
      P_out_day =
        coalesce(SOLPkg_per_ha, 0) +
        coalesce(SEDPkg_per_ha, 0) +
        coalesce(P_GWkg_per_ha, 0)
    )
  
  inputs_outputs <- hru_hay %>%
    group_by(HRU, year) %>%
    summarise(
      P_in_kg_ha_yr  = sum(P_in_day,  na.rm = TRUE),
      P_out_kg_ha_yr = sum(P_out_day, na.rm = TRUE),
      .groups = "drop"
    )
  
  # ---- Change in soil stock from SNU ----
  hay_snu <- snu_joined %>%
    filter(LULC == "ORCD")
  
  delta_soilP <- hay_snu %>%
    group_by(HRU, year) %>%
    summarise(
      soilP_start      = first(soilP_kg_ha),
      soilP_end        = last(soilP_kg_ha),
      delta_soilP_kg_ha = soilP_end - soilP_start,
      .groups = "drop"
    )
  
  # ---- Combine ----
  mass_balance <- inputs_outputs %>%
    left_join(delta_soilP, by = c("HRU", "year")) %>%
    mutate(
      expected_change = P_in_kg_ha_yr - P_out_kg_ha_yr,
      error           = delta_soilP_kg_ha - expected_change
    )
  
  mass_balance
}

#### Outlet export ####

outlet_P_export <- function(run_dir, outlet_rch, p_col = "TOT_Pkg") {
  rch <- readSWAT("rch", run_dir)
  
  rch %>%
    filter(RCH == outlet_rch) %>%
    mutate(
      mdate = as.Date(mdate),
      year  = year(mdate)
    ) %>%
    group_by(year) %>%
    summarise(
      TP_load_kg_yr = sum(.data[[p_col]], na.rm = TRUE),
      .groups = "drop"
    )
}

#### Scenario analysis code ####


analyze_scenario_hay <- function(run_dir, label, outlet_rch, p_col = "TOT_Pkg") {
  list(
    label          = label,
    soilP_table    = hay_soilP_table(run_dir),
    P_loss_hay     = hay_P_loss_annual(run_dir),
    mass_balance   = hay_P_balance(run_dir),
    outlet_export  = outlet_P_export(run_dir, outlet_rch, p_col)
  )
}

run_dirs <- c(
  "~/copy_calib/calibfolderP_baseline",
  "~/copy_calib/BMP_scenarios/ForestBuffer10m",
  "~/copy_calib/BMP_scenarios/Covercrop_WinterRye",
  "~/copy_calib/BMP_scenarios/NM80_injection",
  "~/copy_calib/BMP_scenarios/NoTill",
  "~/copy_calib/BMP_scenarios/CoverCrop_ForestBuffer10m",
  "~/copy_calib/BMP_scenarios/cropremoval_PMining"
)

scenario_labels <- c(
  "Baseline",
  "ForestBuffer10m",
  "CoverCrop",
  "NM80_injection",
  "NoTill",
  "CoverCrop+ForestBuffer10m",
  "CropRemoval_PMining"
)

outlet_rch <- 3   # adjust to your outlet reach

scenario_results <- map2(
  run_dirs,
  scenario_labels,
  ~ analyze_scenario_hay(.x, .y, outlet_rch, p_col = "TOT_Pkg")
)
names(scenario_results) <- scenario_labels


#######################
#### Which BMPs reduce P export the most?####
#######################

outlet_all <- map_dfr(
  scenario_results,
  ~ .x$outlet_export %>%
    mutate(scenario = .x$label),
  .id = "scenario_id"
)

# Join baseline and compute percent change
baseline_outlet <- outlet_all %>%
  filter(scenario == "Baseline") %>%
  select(year, TP_load_baseline = TP_load_kg_yr)

outlet_cmp <- outlet_all %>%
  filter(scenario != "Baseline") %>%
  left_join(baseline_outlet, by = "year") %>%
  mutate(
    dTP_kg   = TP_load_kg_yr - TP_load_baseline,
    dTP_pct  = 100 * dTP_kg / TP_load_baseline
  )
outlet_cmp


##############################
#### Which BMPs create a negative soil P balance (mining)? ####
##############################

# pull mass-balance tables for each scenario
massbal_all <- map_dfr(
  scenario_results,
  ~ .x$mass_balance %>% mutate(scenario = .x$label),
  .id = "scenario_id"
)

# flag mining vs accumulation for hay HRUs
massbal_flagged <- massbal_all %>%
  mutate(
    mining = delta_soilP_kg_ha < 0
  )

# e.g., fraction of hay HRUs that are mining under each scenario + year
mining_summary <- massbal_flagged %>%
  group_by(scenario, year) %>%
  summarise(
    frac_mining = mean(mining),
    mean_delta  = mean(delta_soilP_kg_ha),
    mean_P_in   = mean(P_in_kg_ha_yr),
    mean_P_out  = mean(P_out_kg_ha_yr),
    .groups = "drop"
  )
mining_summary

