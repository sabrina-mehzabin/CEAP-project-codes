library(dplyr)
library(lubridate)
library(tidyr)
library(purrr)

# ---------- 1) Function: year-end soil P (kg/ha) table for HAY (ORCD) HRUs ----------
hay_soilP_table <- function(run_dir) {
  # Read SWAT outputs for this run
  hru <- readSWAT("hru", run_dir)
  snu <- readSWAT("snu", run_dir)
  
  # Make GIS names match
  snu <- snu %>%
    rename(GIS = GISnum)
  
  # Keep only what we need from HRU
  hru_keep <- hru %>%
    select(mdate, HRU, LULC, AREAkm2, GIS)
  
  # Join SNU + HRU info and compute soil P (legacy P) in kg/ha
  snu_joined <- snu %>%
    left_join(hru_keep, by = c("mdate", "GIS")) %>%
    mutate(
      mdate      = as.Date(mdate),
      year       = year(mdate),
      soilP_kg_ha = SOL_P + ORG_P     # legacy P pool per ha
    )
  
  # Only HAY HRUs
  hay_snu <- snu_joined %>%
    filter(LULC == "ORCD")
  
  # For each HRU and year, keep only the last day of that year
  hay_year_end <- hay_snu %>%
    group_by(HRU, year) %>%
    filter(mdate == max(mdate)) %>%
    slice_tail(n = 1) %>%
    ungroup() %>%
    select(HRU, year, soilP_kg_ha)
  
  # Wide table: rows = HRUs, columns = years
  hay_legacy_table <- hay_year_end %>%
    pivot_wider(
      names_from  = year,
      values_from = soilP_kg_ha
    ) %>%
    arrange(HRU)
  
  hay_legacy_table
}

# ---------- 2) Apply to all scenarios ----------

run_dirs <- c(
  "~/copy_calib/calibfolderP_baseline",
  "~/copy_calib/BMP_scenarios/ForestBuffer10m",
  "~/copy_calib/BMP_scenarios/Covercrop_WinterRye",
  "~/copy_calib/BMP_scenarios/NM80_injection",
  "~/copy_calib/BMP_scenarios/NoTill",
  "~/copy_calib/BMP_scenarios/CoverCrop_ForestBuffer10m",
  "~/copy_calib/BMP_scenarios/cropremoval_PMining"
)

scenario_labels <- c(
  "Baseline",
  "ForestBuffer10m",
  "CoverCrop",
  "NM80_injection",
  "NoTill",
  "CoverCrop+ForestBuffer10m",
  "CropRemoval_PMining"
)

# A named list of hay legacy tables, one per scenario
hay_legacy_tables <- map(run_dirs, hay_soilP_table) |>
  set_names(scenario_labels)

# Example: see baseline table
hay_legacy_tables$Baseline

# Example: table for NM80_injection
hay_legacy_tables$NM80_injection


###########
###Legacy P loss under baseline/ current management###
###########


library(dplyr)
library(lubridate)
library(SWATplusR)   # or whatever package gives you readSWAT()

base_dir <- "~/copy_calib/calibfolderP_baseline"

###########
### Legacy P loss under baseline / current management
###########

base_dir <- "~/copy_calib/calibfolderP_baseline"
hay_P_loss_annual <- function(run_dir) {
  
  # Read daily HRU output for this run
  hru <- readSWAT("hru", run_dir)
  
  hru %>%
    # 1) Only hay HRUs
    filter(LULC == "ORCD") %>%
    
    # 2) Make date & year and compute daily P loss (kg/ha/day)
    mutate(
      mdate = as.Date(mdate),
      year  = year(mdate),
      P_loss_day_kg_ha =
        coalesce(SOLPkg_per_ha, 0) +   # dissolved P in runoff
        coalesce(SEDPkg_per_ha, 0) +   # particulate P with sediment
        coalesce(P_GWkg_per_ha, 0)     # P via groundwater
    ) %>%
    
    # 3) Aggregate to annual loss per HRU (kg/ha/yr)
    group_by(HRU, year) %>%
    summarise(
      P_loss_kg_ha_yr = sum(P_loss_day_kg_ha, na.rm = TRUE),
      .groups = "drop"
    )
}

# Example: baseline run
hay_loss_baseline <- hay_P_loss_annual(base_dir)
head(hay_loss_baseline)



######################
### Annual export at watershed outlet
######################

outlet_P_export <- function(run_dir, outlet_rch, p_col = "TOT_Pkg") {
  rch <- readSWAT("rch", run_dir)
  
  rch %>%
    filter(RCH == outlet_rch) %>%       # your outlet reach
    mutate(
      mdate = as.Date(mdate),
      year  = year(mdate)
    ) %>%
    group_by(year) %>%
    summarise(
      TP_load_kg_yr = sum(.data[[p_col]], na.rm = TRUE),
      .groups = "drop"
    )
}

# Example: baseline outlet export (change RCH number if needed)
outlet_P_baseline <- outlet_P_export(base_dir, outlet_rch = 3, p_col = "TOT_Pkg")
outlet_P_baseline
