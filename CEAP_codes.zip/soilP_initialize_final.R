##############################################################################
# Soil P initialization — fixed values + 70/30 split inside HAY
# - HAY (perennial):      SOL_SOLP(1) = 2.50 ppm, SOL_SOLP(2) = 1.50 ppm
# - CornFromHay (tilled): SOL_SOLP(1) = 3.692 ppm, SOL_SOLP(2) = 3.692 ppm
# - FRSD:                 same value in layers 1–2 (default 2.50 ppm)
# - AGRR:                 same value in layers 1–2 (default 2.50 ppm)
# - Others:               same value in layers 1–2 (default 2.50 ppm)
# Writes SOL_SOLP for layers 1–2 in .chm with F12.2 fixed-width formatting.
##############################################################################

############################
# A) CONFIG
############################
sol_dir          <- "~/copy_calib/calibfolder2"   # folder containing *.chm

# Hay (perennial) vertical profile
ppm_hay_top      <- 2.50
ppm_hay_second   <- 1.50

# CornFromHay (tilled) vertical profile
ppm_corn_top     <- 3.692
ppm_corn_second  <- 3.692

# Other LUSE defaults (applied to both layers 1–2)
ppm_frsd         <- 2.50
ppm_agrr         <- 2.50
ppm_other        <- 2.50        # default for any other LUSE (if present)

layers_to_set    <- c(1L, 2L)   # set layers 1 and 2
hay_split_seed   <- 2025
hay_split_csv    <- file.path(sol_dir, "hay_corn_split.csv")          # persisted 70/30 split
mapping_csv      <- file.path(sol_dir, "soilP_init_mapping_for_mgt.csv")

############################
# B) LIBS
############################
suppressPackageStartupMessages({
  library(readr); library(dplyr); library(stringr)
})

############################
# C) SCAN .chm HEADERS → (file, HRU_ID, LUSE)
############################
chm_files <- list.files(sol_dir, pattern = "\\.chm$", full.names = TRUE)
stopifnot(length(chm_files) > 0)

read_header_info <- function(fp) {
  first_line <- readr::read_lines(fp, n_max = 1)
  hru_token  <- stringr::str_extract(first_line, "HRU:\\s*\\d+")
  luse_token <- stringr::str_extract(first_line, "Luse:\\s*[^\\s]+")
  hru_id     <- as.integer(stringr::str_extract(hru_token, "\\d+"))
  luse       <- sub("^Luse:\\s*", "", luse_token)
  tibble::tibble(file = fp, HRU_ID = hru_id, LUSE = luse)
}

file_lookup <- bind_rows(lapply(chm_files, read_header_info)) %>%
  filter(!is.na(HRU_ID) & nzchar(LUSE))

############################
# D) CREATE / LOAD 70/30 SPLIT INSIDE HAY
############################
if (file.exists(hay_split_csv)) {
  message("Loading existing HAY split: ", hay_split_csv)
  hay_split <- readr::read_csv(hay_split_csv, show_col_types = FALSE) %>%
    dplyr::select(HRU_ID, group)  # keep only needed columns
} else {
  set.seed(hay_split_seed)
  hay_ids <- file_lookup %>% filter(LUSE == "HAY") %>% pull(HRU_ID)
  if (length(hay_ids) == 0L) {
    hay_split <- tibble::tibble(HRU_ID = integer(), group = character())
  } else {
    n_hay      <- length(hay_ids)
    n_cornlike <- max(1L, round(0.30 * n_hay))  # 30% of HAY
    corn_ids   <- sample(hay_ids, size = n_cornlike)
    hay_split <- tibble::tibble(
      HRU_ID = hay_ids,
      group  = ifelse(HRU_ID %in% corn_ids, "CornFromHay", "Hay")
    )
  }
  readr::write_csv(hay_split, hay_split_csv)
  message("Saved HAY split mapping to: ", hay_split_csv)
}

############################
# E) BUILD FINAL ASSIGNMENT TABLE
############################
# Base table with placeholder group; Hay groups will come from hay_split
assign_base <- file_lookup %>%
  mutate(group = ifelse(LUSE == "HAY", NA_character_, "NonHay"))

assign_final <- assign_base %>%
  left_join(hay_split, by = "HRU_ID", suffix = c("", "_hay")) %>%
  mutate(
    # For HAY LUSE, prefer split group ("Hay" or "CornFromHay");
    # otherwise keep "NonHay"
    group = case_when(
      LUSE == "HAY" & !is.na(group_hay) ~ group_hay,
      LUSE == "HAY" &  is.na(group_hay) ~ "Hay",
      TRUE                              ~ group
    ),
    # Top layer P (layer 1)
    top_ppm = case_when(
      group == "Hay"         ~ ppm_hay_top,
      group == "CornFromHay" ~ ppm_corn_top,
      LUSE == "FRSD"         ~ ppm_frsd,
      LUSE == "AGRR"         ~ ppm_agrr,
      TRUE                   ~ ppm_other
    ),
    # Second layer P (layer 2)
    second_ppm = case_when(
      group == "Hay"         ~ ppm_hay_second,
      group == "CornFromHay" ~ ppm_corn_second,
      LUSE == "FRSD"         ~ ppm_frsd,
      LUSE == "AGRR"         ~ ppm_agrr,
      TRUE                   ~ ppm_other
    )
  ) %>%
  select(file, HRU_ID, LUSE, group, top_ppm, second_ppm)

edit_tbl <- assign_final %>% filter(!is.na(top_ppm))
message("Will edit ", nrow(edit_tbl), " CHM files.")

############################
# F) FIXED-WIDTH HELPERS (F12.2 at columns 28–147)
############################
.chm_layer_cols <- function(n = 10L, start = 28L, width = 12L) {
  # Layer 1: cols 28–39, Layer 2: 40–51, etc.
  starts <- start + (0:(n - 1)) * width
  data.frame(i = seq_len(n), start = starts, end = starts + width - 1L)
}

read_chm_line_vals <- function(line, n_layers = 10L) {
  cols <- .chm_layer_cols(n_layers)
  vals <- numeric(n_layers)
  for (k in seq_len(n_layers)) {
    seg <- substr(line, cols$start[k], cols$end[k])
    vals[k] <- suppressWarnings(as.numeric(trimws(seg)))
    if (is.na(vals[k])) vals[k] <- 0
  }
  vals
}

write_chm_line_vals <- function(line, new_vals) {
  n_layers <- length(new_vals)
  if (nchar(line) < 27) line <- sprintf("%-27s", line)  # ensure prefix area exists
  prefix <- substr(line, 1L, 27L)
  # write all layers as F12.2, concatenated
  block  <- paste0(sprintf("%12.2f", new_vals), collapse = "")
  paste0(prefix, block)
}


replace_layers_in_labeled_line <- function(line, label_regex, layer_ids, layer_vals) {
  if (!grepl(label_regex, line)) return(line)
  stopifnot(length(layer_ids) == length(layer_vals))
  cur <- read_chm_line_vals(line, n_layers = 10L)
  cur[layer_ids] <- layer_vals
  write_chm_line_vals(line, cur)
}

# Writer: update SOL_SOLP only (labile P), leave SOL_ORGP untouched
update_chm_solp_only <- function(path, layer_vals, layer_ids = layers_to_set, do_backup = TRUE) {
  txt <- readLines(path, warn = FALSE)
  if (do_backup) {
    bak <- paste0(path, ".bak")
    if (!file.exists(bak)) file.copy(path, bak, overwrite = FALSE)
  }
  ix_lab <- grep("^\\s*Soil\\s+labile\\s+P\\b", txt)
  if (length(ix_lab) == 1L) {
    txt[ix_lab] <- replace_layers_in_labeled_line(
      txt[ix_lab],
      label_regex = "^\\s*Soil\\s+labile\\s+P\\b",
      layer_ids   = layer_ids,
      layer_vals  = layer_vals
    )
  }
  writeLines(txt, path, useBytes = TRUE)
  invisible(TRUE)
}

############################
# G) APPLY EDITS
############################
edited <- 0L
for (i in seq_len(nrow(edit_tbl))) {
  f   <- edit_tbl$file[i]
  v   <- c(edit_tbl$top_ppm[i], edit_tbl$second_ppm[i])
  update_chm_solp_only(f, layer_vals = v, layer_ids = layers_to_set)
  edited <- edited + 1L
}
cat("Soil-P initialization complete: edited", edited, "files.\n")

# Quick sanity print on one updated file
if (edited > 0L) {
  tf  <- edit_tbl$file[1]
  txt <- readLines(tf, warn = FALSE)
  cat(grep("^\\s*Soil\\s+labile\\s+P\\b", txt, value = TRUE), "\n")
}

############################
# H) EXPORT MAPPING FOR .mgt STEP
############################
# group ∈ {"Hay","CornFromHay","NonHay"} and top-layer ppm used
mapping_for_mgt <- assign_final %>%
  mutate(init_ppm = top_ppm) %>%
  select(HRU_ID, LUSE, group, init_ppm)

readr::write_csv(mapping_for_mgt, mapping_csv)
message("Wrote mapping for .mgt step: ", mapping_csv)

