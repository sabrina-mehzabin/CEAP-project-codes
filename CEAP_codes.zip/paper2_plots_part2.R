suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(lubridate)
  library(ggplot2)
})

# make sure this matches your path
load("readSWAT.R")   # or: source("~/swat_LOC/R/readSWAT_3.R")

prep_snu_joined <- function(run_dir) {
  hru <- readSWAT("hru", run_dir)
  snu <- readSWAT("snu", run_dir)
  
  snu <- snu %>%
    rename(GIS = GISnum)
  
  hru_keep <- hru %>%
    select(mdate, HRU, LULC, AREAkm2, GIS)
  
  snu_joined <- snu %>%
    left_join(hru_keep, by = c("mdate", "GIS")) %>%
    mutate(
      mdate      = as.Date(mdate),
      year       = year(mdate),
      soilP_kg_ha = SOL_P + ORG_P
    )
  
  list(
    hru        = hru,
    snu_joined = snu_joined
  )
}

hay_soilP_table <- function(run_dir) {
  obj <- prep_snu_joined(run_dir)
  snu_joined <- obj$snu_joined
  
  hay_snu <- snu_joined %>%
    filter(LULC == "ORCD")
  
  hay_year_end <- hay_snu %>%
    group_by(HRU, year) %>%
    filter(mdate == max(mdate)) %>%
    slice_tail(n = 1) %>%
    ungroup() %>%
    select(HRU, year, soilP_kg_ha)
  
  hay_year_end %>%
    pivot_wider(names_from = year, values_from = soilP_kg_ha) %>%
    arrange(HRU)
}

hay_P_balance <- function(run_dir) {
  obj <- prep_snu_joined(run_dir)
  hru <- obj$hru
  snu_joined <- obj$snu_joined
  
  hru_hay <- hru %>%
    filter(LULC == "ORCD") %>%
    mutate(
      mdate = as.Date(mdate),
      year  = year(mdate),
      P_in_day =
        coalesce(P_APPkg_per_ha, 0) +
        coalesce(PAUTOkg_per_ha, 0) +
        coalesce(PGRZkg_per_ha, 0) +
        coalesce(PCFRTkg_per_ha, 0),
      P_out_day =
        coalesce(SOLPkg_per_ha, 0) +
        coalesce(SEDPkg_per_ha, 0) +
        coalesce(P_GWkg_per_ha, 0)
    )
  
  inputs_outputs <- hru_hay %>%
    group_by(HRU, year) %>%
    summarise(
      P_in_kg_ha_yr  = sum(P_in_day,  na.rm = TRUE),
      P_out_kg_ha_yr = sum(P_out_day, na.rm = TRUE),
      .groups = "drop"
    )
  
  hay_snu <- snu_joined %>%
    filter(LULC == "ORCD")
  
  delta_soilP <- hay_snu %>%
    group_by(HRU, year) %>%
    summarise(
      soilP_start       = first(soilP_kg_ha),
      soilP_end         = last(soilP_kg_ha),
      delta_soilP_kg_ha = soilP_end - soilP_start,
      .groups = "drop"
    )
  
  inputs_outputs %>%
    left_join(delta_soilP, by = c("HRU", "year")) %>%
    mutate(
      expected_change = P_in_kg_ha_yr - P_out_kg_ha_yr,
      error           = delta_soilP_kg_ha - expected_change
    )
}

whole_soilP_table <- function(run_dir) {
  obj <- prep_snu_joined(run_dir)
  snu_joined <- obj$snu_joined
  
  year_end <- snu_joined %>%
    group_by(HRU, LULC, year) %>%
    filter(mdate == max(mdate)) %>%
    slice_tail(n = 1) %>%
    ungroup() %>%
    select(HRU, LULC, year, soilP_kg_ha)
  
  year_end %>%
    pivot_wider(names_from = year, values_from = soilP_kg_ha) %>%
    arrange(HRU)
}

whole_P_balance <- function(run_dir) {
  obj <- prep_snu_joined(run_dir)
  hru <- obj$hru
  snu_joined <- obj$snu_joined
  
  hru_all <- hru %>%
    mutate(
      mdate = as.Date(mdate),
      year  = year(mdate),
      P_in_day =
        coalesce(P_APPkg_per_ha, 0) +
        coalesce(PAUTOkg_per_ha, 0) +
        coalesce(PGRZkg_per_ha, 0) +
        coalesce(PCFRTkg_per_ha, 0),
      P_out_day =
        coalesce(SOLPkg_per_ha, 0) +
        coalesce(SEDPkg_per_ha, 0) +
        coalesce(P_GWkg_per_ha, 0)
    )
  
  inputs_outputs <- hru_all %>%
    group_by(HRU, year) %>%
    summarise(
      P_in_kg_ha_yr  = sum(P_in_day,  na.rm = TRUE),
      P_out_kg_ha_yr = sum(P_out_day, na.rm = TRUE),
      .groups = "drop"
    )
  
  delta_soilP <- snu_joined %>%
    group_by(HRU, year) %>%
    summarise(
      soilP_start       = first(soilP_kg_ha),
      soilP_end         = last(soilP_kg_ha),
      delta_soilP_kg_ha = soilP_end - soilP_start,
      .groups = "drop"
    )
  
  inputs_outputs %>%
    left_join(delta_soilP, by = c("HRU", "year")) %>%
    mutate(
      expected_change = P_in_kg_ha_yr - P_out_kg_ha_yr,
      error           = delta_soilP_kg_ha - expected_change
    )
}

outlet_P_export <- function(run_dir, outlet_rch, p_col = "TOT_Pkg") {
  rch <- readSWAT("rch", run_dir)
  
  rch %>%
    filter(RCH == outlet_rch) %>%
    mutate(
      mdate = as.Date(mdate),
      year  = year(mdate)
    ) %>%
    group_by(year) %>%
    summarise(
      TP_load_kg_yr = sum(.data[[p_col]], na.rm = TRUE),
      .groups = "drop"
    )
}

analyze_scenario_hay <- function(run_dir, label, outlet_rch, p_col = "TOT_Pkg") {
  list(
    label        = label,
    soilP_table  = hay_soilP_table(run_dir),
    mass_balance = hay_P_balance(run_dir),
    outlet_export = outlet_P_export(run_dir, outlet_rch, p_col)
  )
}

analyze_scenario_all <- function(run_dir, label, outlet_rch, p_col = "TOT_Pkg") {
  list(
    label        = label,
    soilP_table  = whole_soilP_table(run_dir),
    mass_balance = whole_P_balance(run_dir),
    outlet_export = outlet_P_export(run_dir, outlet_rch, p_col)
  )
}

run_dirs <- c(
  "~/copy_calib/calibfolderP_baseline_40yrWGN_new",
  "~/copy_calib/BMP_scenarios_40yr_new/Covercrop_WinterRye",
  "~/copy_calib/BMP_scenarios_40yr_new/cropremoval_PMining",
  "~/copy_calib/BMP_scenarios_40yr_new/ForestBuffer10m",
  "~/copy_calib/BMP_scenarios_40yr_new/MultiBMP_Rye_NM80_Buffer",
  "~/copy_calib/BMP_scenarios_40yr_new/NM80_injection",
  "~/copy_calib/BMP_scenarios_40yr_new/NoTill"
)

scenario_labels <- c(
  "Baseline",
  "Covercrop_WinterRye",
  "cropremoval_PMining",
  "ForestBuffer10m",
  "MultiBMP_Rye_NM80_Buffer",
  "NM80_injection",
  "NoTill"
)

outlet_rch <- 3

scenario_results_hay <- map2(
  run_dirs,
  scenario_labels,
  ~ analyze_scenario_hay(.x, .y, outlet_rch, p_col = "TOT_Pkg")
)
names(scenario_results_hay) <- scenario_labels

scenario_results_all <- map2(
  run_dirs,
  scenario_labels,
  ~ analyze_scenario_all(.x, .y, outlet_rch, p_col = "TOT_Pkg")
)
names(scenario_results_all) <- scenario_labels

delta_hay <- map_dfr(
  scenario_results_hay,
  ~ .x$mass_balance %>%
    select(HRU, year, delta_soilP_kg_ha) %>%
    mutate(scenario = .x$label),
  .id = "scenario_id"
)

# 40-yr cumulative Δ soil P per HRU (hay only)
delta40_hay <- delta_hay %>%
  group_by(scenario, HRU) %>%
  summarise(
    delta_soilP_kg_ha_40 = sum(delta_soilP_kg_ha, na.rm = TRUE),
    .groups = "drop"
  )

ggplot(delta40_hay, aes(x = scenario, y = delta_soilP_kg_ha_40)) +
  geom_boxplot(outlier.alpha = 0.3) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  labs(
    x = "Scenario",
    y = "40-yr Δ soil P in hay HRUs (kg/ha)"
  ) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

delta_all <- map_dfr(
  scenario_results_all,
  ~ .x$mass_balance %>%
    select(HRU, year, delta_soilP_kg_ha) %>%
    mutate(scenario = .x$label),
  .id = "scenario_id"
)

delta40_all <- delta_all %>%
  group_by(scenario, HRU) %>%
  summarise(
    delta_soilP_kg_ha_40 = sum(delta_soilP_kg_ha, na.rm = TRUE),
    .groups = "drop"
  )

ggplot(delta40_all, aes(x = scenario, y = delta_soilP_kg_ha_40)) +
  geom_boxplot(outlier.alpha = 0.3) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  labs(
    x = "Scenario",
    y = "40-yr Δ soil P in all HRUs (kg/ha)"
  ) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

write.csv(delta40_all, "deltaP_40_all.csv", row.names = FALSE)
write.csv(delta40_hay, "deltaP_40_hay.csv", row.names = FALSE)