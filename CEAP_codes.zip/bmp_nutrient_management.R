##############################################################################
# BMP: NM80_injection
# - Start from P-calibrated baseline
# - Copy to BMP_scenarios/NM80_injection
# - On HRUs in Hay/CornFromHay 70/30 split:
#     * Reduce commercial fertilizer FERT_KG to 80% of original
#     * For manure (FERT_ID == 53): set FRT_SURFACE = 0.00 (injection)
##############################################################################

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(stringr)
})

## ---------- USER INPUT -----------------------------------------------------

# 1) P-calibrated baseline (already has your final .mgt schedules)
baselineP_dir  <- "~/copy_calib/calibfolderP_baseline_final"

# 2) Folder where BMP scenarios live
bmp_root       <- "~/copy_calib/BMP_scenarios_final"

# 3) Scenario name for this BMP
scenario_name  <- "NM80_injection"
scenario_dir   <- file.path(bmp_root, scenario_name)

# ############# 40 years ################
# 
# # 1) Use the NEW 40-yr baseline with weather generator
# baselineP_dir  <- "~/copy_calib/calibfolderP_baseline_40yrWGN_new"
# 
# # 2) (Recommended) keep 40-yr BMPs separate from old 8-yr BMPs
# bmp_root       <- "~/copy_calib/BMP_scenarios_40yr_new"
# 
# scenario_name  <- "NM80_injection"
# scenario_dir   <- file.path(bmp_root, scenario_name)


# 4) Soil-P initialization folder (same as in your soil P init script)
#    This MUST already contain hay_corn_split.csv from that script.
sol_dir        <- "~/copy_calib/calibfolder1"
hay_split_csv  <- file.path(sol_dir, "hay_corn_split.csv")

# 5) Nutrient management settings
P_mult          <- 0.80        # 80% of original fertilizer amount
manure_fert_ids <- c(53L)      # liquid manure FERT_ID(s) to be injected

## ---------- PREP & COPY BASELINE -------------------------------------------

baselineP_dir <- path.expand(baselineP_dir)
scenario_dir  <- path.expand(scenario_dir)
sol_dir       <- path.expand(sol_dir)

if (!dir.exists(baselineP_dir)) {
  stop("baselineP_dir not found: ", baselineP_dir)
}

dir.create(scenario_dir, recursive = TRUE, showWarnings = FALSE)

# Copy CONTENTS of baseline directory into scenario_dir
baseline_files <- list.files(baselineP_dir, full.names = TRUE, recursive = TRUE)

for (src in baseline_files) {
  # path relative to baselineP_dir
  rel  <- sub(paste0("^", baselineP_dir, "/"), "", src)
  dest <- file.path(scenario_dir, rel)
  dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
  file.copy(src, dest, overwrite = TRUE)
}

cat("Baseline copied into scenario directory:\n  ", scenario_dir, "\n")

## ---------- LOAD EXISTING 70/30 HAY SPLIT ----------------------------------
# We are REUSING the same hay_corn_split.csv created by soil P init,
# so we target exactly the same HRUs (no new random split).

if (!file.exists(hay_split_csv)) {
  stop("hay_corn_split.csv not found at: ", hay_split_csv,
       "\nRun the soil P initialization script first so this file exists.")
}

hay_split <- read_csv(hay_split_csv, show_col_types = FALSE) %>%
  mutate(
    HRU_ID = as.integer(HRU_ID),
    group  = trimws(group)
  )

# HRUs to which hay/corn rotations were applied in your original script
bmp_hru_ids <- hay_split %>%
  filter(group %in% c("Hay", "CornFromHay")) %>%
  pull(HRU_ID) %>%
  unique()

cat("Number of HRUs in Hay/CornFromHay split: ", length(bmp_hru_ids), "\n")

## ---------- HELPERS TO PARSE / EDIT .MGT LINES -----------------------------

# Parse HRU_ID from .mgt header line: "HRU:   23  Subbasin: ..."
parse_hru_id_from_mgt <- function(fp) {
  first_line <- readr::read_lines(fp, n_max = 1)
  hru_token  <- stringr::str_extract(first_line, "HRU:\\s*\\d+")
  if (is.na(hru_token)) return(NA_integer_)
  as.integer(stringr::str_extract(hru_token, "\\d+"))
}

parse_int <- function(line, start, end) {
  as.integer(trimws(substr(line, start, end)))
}

parse_num <- function(line, start, end) {
  as.numeric(trimws(substr(line, start, end)))
}

# Core: update fertilizer line for NM80_injection
update_fert_line_nm80 <- function(line, P_mult, manure_ids) {
  # Only touch fertilizer operations (MGT_OP = 3)
  op <- parse_int(line, 17, 18)
  if (is.na(op) || op != 3L) return(line)
  
  fert_id     <- parse_int(line, 20, 23)
  fert_kg     <- parse_num(line, 32, 43)
  frt_surface <- parse_num(line, 45, 50)
  
  # If this is a manure fertilizer line (e.g., FERT_ID 53)
  if (!is.na(fert_id) && fert_id %in% manure_ids) {
    # 1) DO NOT change FERT_KG (100% of original)
    # 2) Set FRT_SURFACE = 0.00 (injection)
    if (!is.na(frt_surface)) {
      frt_surface <- 0.00
    }
    
  } else {
    # Commercial fertilizer:
    # 1) Reduce fertilizer amount to 80%
    if (!is.na(fert_kg)) {
      fert_kg <- fert_kg * P_mult
    }
    # 2) Leave FRT_SURFACE as it is (no change)
  }
  
  # Write back with original fixed-width formatting
  if (!is.na(fert_kg)) {
    substr(line, 32, 43) <- sprintf("%12.5f", fert_kg)
  }
  if (!is.na(frt_surface)) {
    substr(line, 45, 50) <- sprintf("%6.2f", frt_surface)
  }
  
  line
}


# Edit a single .mgt file in the scenario folder
edit_mgt_file_nm80 <- function(mgt_path, P_mult, manure_ids) {
  lines <- readLines(mgt_path, warn = FALSE)
  if (!length(lines)) return(invisible(FALSE))
  
  ops_line <- grep("^\\s*Operation\\s+Schedule:", lines)
  if (!length(ops_line)) return(invisible(FALSE))
  ops_line <- ops_line[1]
  
  # Edit only the operation schedule block
  i <- ops_line + 1L
  while (i <= length(lines) &&
         nzchar(trimws(lines[i])) &&
         !grepl("^\\s*[A-Za-z].*:\\s*$", lines[i])) {
    
    lines[i] <- update_fert_line_nm80(lines[i],
                                      P_mult    = P_mult,
                                      manure_ids = manure_ids)
    i <- i + 1L
  }
  
  # Backup and write
  bak <- paste0(mgt_path, ".NM80_injection.bak")
  file.copy(mgt_path, bak, overwrite = TRUE)
  writeLines(lines, mgt_path, useBytes = TRUE)
  
  invisible(TRUE)
}

## ---------- APPLY BMP ONLY TO HAY / CORN-FROM-HAY HRUs ---------------------

mgt_files <- list.files(scenario_dir,
                        pattern = "^[^.].*\\.mgt$",
                        full.names = TRUE,
                        recursive = TRUE)

count_edit <- 0L
count_skip <- 0L

for (fp in mgt_files) {
  hru_id <- parse_hru_id_from_mgt(fp)
  
  # Skip if HRU_ID not found or not in the Hay/CornFromHay pool
  if (is.na(hru_id) || !(hru_id %in% bmp_hru_ids)) {
    count_skip <- count_skip + 1L
    next
  }
  
  edit_mgt_file_nm80(fp,
                     P_mult     = P_mult,
                     manure_ids = manure_fert_ids)
  count_edit <- count_edit + 1L
}

cat("\nBMP NM80_injection summary:",
    "\n  .mgt files edited (Hay/CornFromHay HRUs): ", count_edit,
    "\n  .mgt files skipped:                       ", count_skip,
    "\n  Scenario directory:                       ", scenario_dir, "\n\n")

## ---------- RUN SWAT IN SCENARIO FOLDER ------------------------------------

pacman::p_load(SWATmodel,dplyr,EcoHydRology,base,topmodel,utils, lubridate,stringr,diffobj,tidyr,rnoaa,readr,ggplot2)
run_swat <- function(swat_exe  = "~/new_swat/rev688_64rel_linux",
                     work_dir  = scenario_dir) {
  
  swat_exe <- path.expand(swat_exe)
  work_dir <- path.expand(work_dir)
  
  if (!file.exists(swat_exe)) stop("SWAT executable not found: ", swat_exe)
  if (!dir.exists(work_dir))  stop("Working dir not found: ", work_dir)
  
  setwd(work_dir)
  
  message("Cleaning old output files …")
  old_out <- list.files(pattern = "output\\.")
  if (length(old_out)) file.remove(old_out)
  
  message("Running SWAT in NM80_injection …")
  system(shQuote(swat_exe), intern = FALSE)
  
  new_out <- list.files(pattern = "output\\.")
  if (length(new_out)) {
    message("SWAT run completed ✔")
    return(new_out)
  } else {
    stop("SWAT produced no output files in scenario_dir.")
  }
}

# ── run it ───────────────────────────────────────────────────────────────────
output_files <- run_swat()
cat("Generated output files in NM80_injection:\n"); print(output_files)


#######################
myhomedir = Sys.getenv("HOME")
basedir = myhomedir
codedir = paste0(basedir,"/swat_LOC/R" )
source(paste0(codedir, "/readSWAT_3.R"))
save(readSWAT,file="readSWAT.R")
# out_Calib_Tflo_hru <- readSWAT("hru")
# output_hru_1 = out_Calib_Tflo_hru[out_Calib_Tflo_hru$SUB==1,]

# 5. Read output.rch and keep reach 3
load("readSWAT.R")
outdata  <- readSWAT("rch", ".")
rch_data <- subset(outdata, RCH == 3)
rch_data$Date <- rch_data$mdate

# 6. Read event definitions + observed loads
Events <- read.csv("Events.csv")
Events$start_date <- as.Date(Events$start_date, "%m/%d/%Y")
Events$end_date   <- as.Date(Events$end_date,   "%m/%d/%Y")

# 7. Aggregate simulated TP per event (kg)
sim_P <- numeric(nrow(Events))
for (i in seq_len(nrow(Events))) {
  ev <- subset(rch_data,
               Date >= Events$start_date[i] &
                 Date <= Events$end_date[i])
  sim_P[i] <- sum(ev$TOT_Pkg, na.rm = TRUE)
}
Events$Total_P_simulated <- sim_P




#####################
###plot###

library(ggplot2)


ggplot(Events, aes(x = end_date)) +
  
  # Points for simulated & observed
  geom_line(aes(y = Total_P_simulated, color = "Simulated"), size = 2, alpha = 0.9) +
  geom_line(aes(y = Tot_P, color = "Observed"), size = 2, alpha = 0.9) +
  
  # Labels
  labs(
    x = "Time",
    y = "Total P (kg)",
    color = ""
  ) +
  
  # Colors
  scale_color_manual(
    values = c("Simulated" = "magenta", "Observed" = "orange")
  ) +
  
  # Theme
  theme_minimal(base_size = 15) +
  theme(
    plot.title = element_text(size = 16, hjust = 0.5),
    axis.title = element_text(size = 15),
    axis.text  = element_text(size = 13),
    panel.border = element_rect(color = "black", fill = NA, size = 1),
    plot.margin = margin(t = 5, r = 25, b = 5, l = 5, unit = "pt")
  )
