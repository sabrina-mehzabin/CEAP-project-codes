suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(lubridate)
  library(ggplot2)
})

myhomedir = Sys.getenv("HOME")
basedir = myhomedir
codedir = paste0(basedir,"/swat_LOC/R" ) 

# load your existing readSWAT helper
source(file.path(codedir, "readSWAT_3.R"))
save(readSWAT, file = "readSWAT.R")

prep_snu_joined <- function(run_dir) {
  hru <- readSWAT("hru", run_dir)
  snu <- readSWAT("snu", run_dir)
  
  snu <- snu %>%
    rename(GIS = GISnum)
  
  hru_keep <- hru %>%
    select(mdate, HRU, LULC, AREAkm2, GIS)
  
  snu_joined <- snu %>%
    left_join(hru_keep, by = c("mdate", "GIS")) %>%
    mutate(
      mdate       = as.Date(mdate),
      year        = year(mdate),
      soilP_kg_ha = SOL_P + ORG_P          # legacy soil P per ha
    )
  
  list(
    hru        = hru,
    snu_joined = snu_joined
  )
}

summarise_outlet_TP_40yr <- function(run_dir,
                                     scen_name,
                                     outlet_rch   = 3,
                                     warmup_years = 10) {
  rch <- readSWAT("rch", run_dir) %>%
    filter(RCH == outlet_rch) %>%
    mutate(
      mdate = as.Date(mdate),
      year  = year(mdate)
    )
  
  years <- sort(unique(rch$year))
  analysis_years <- years[(warmup_years + 1):length(years)]
  
  rch %>%
    filter(year %in% analysis_years) %>%
    group_by(year) %>%
    summarise(
      TP_load_kg_yr = sum(TOT_Pkg, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      scenario = scen_name
    )
}

summarise_soilP_hay_40yr <- function(run_dir,
                                     scen_name,
                                     warmup_years = 10) {
  obj <- prep_snu_joined(run_dir)
  snu_joined <- obj$snu_joined
  
  hay_snu <- snu_joined %>%
    filter(LULC == "ORCD")
  
  years <- sort(unique(hay_snu$year))
  analysis_years <- years[(warmup_years + 1):length(years)]
  
  hay_snu %>%
    filter(year %in% analysis_years) %>%
    group_by(year) %>%
    summarise(
      mean_soilP_kg_ha = mean(soilP_kg_ha, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      scenario = scen_name,
      group    = "Hay HRUs"
    )
}

summarise_soilP_ws_40yr <- function(run_dir,
                                    scen_name,
                                    warmup_years = 10) {
  obj <- prep_snu_joined(run_dir)
  snu_joined <- obj$snu_joined
  
  years <- sort(unique(snu_joined$year))
  analysis_years <- years[(warmup_years + 1):length(years)]
  
  snu_joined %>%
    filter(year %in% analysis_years) %>%
    group_by(year) %>%
    summarise(
      # area-weighted mean soil P
      mean_soilP_kg_ha = sum(soilP_kg_ha * AREAkm2, na.rm = TRUE) /
        sum(AREAkm2, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    mutate(
      scenario = scen_name,
      group    = "Whole watershed"
    )
}

run_dirs_40 <- c(
  "~/copy_calib/calibfolderP_baseline_40yrWGN_new",
  "~/copy_calib/BMP_scenarios_40yr_new/Covercrop_WinterRye",
  "~/copy_calib/BMP_scenarios_40yr_new/cropremoval_PMining",
  "~/copy_calib/BMP_scenarios_40yr_new/ForestBuffer10m",
  "~/copy_calib/BMP_scenarios_40yr_new/MultiBMP_Rye_NM80_Buffer",
  "~/copy_calib/BMP_scenarios_40yr_new/NM80_injection",
  "~/copy_calib/BMP_scenarios_40yr_new/NoTill"
)

scenario_labels_40 <- c(
  "Baseline",
  "Covercrop_WinterRye",
  "cropremoval_PMining",
  "ForestBuffer10m",
  "MultiBMP_Rye_NM80_Buffer",
  "NM80_injection",
  "NoTill"
)

outlet_rch <- 3

# Outlet TP (years 11–40)
outlet_40_all <- map2_dfr(
  run_dirs_40,
  scenario_labels_40,
  ~ summarise_outlet_TP_40yr(.x, .y, outlet_rch = outlet_rch)
)

# Hay-only soil P trajectories
soilP_hay_40_all <- map2_dfr(
  run_dirs_40,
  scenario_labels_40,
  ~ summarise_soilP_hay_40yr(.x, .y)
)

# Whole-watershed soil P trajectories
soilP_ws_40_all <- map2_dfr(
  run_dirs_40,
  scenario_labels_40,
  ~ summarise_soilP_ws_40yr(.x, .y)
)

# Combine hay + watershed for plotting if you like
soilP_40_all <- bind_rows(soilP_hay_40_all, soilP_ws_40_all)

ggplot(outlet_40_all,
       aes(x = scenario, y = TP_load_kg_yr)) +
  geom_boxplot(outlier.alpha = 0.4) +
  labs(
    x = "Scenario",
    y = "Annual TP load at outlet (kg/yr, years 11–40)"
  ) +
  theme_bw() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1)
  )

ggplot(soilP_hay_40_all,
       aes(x = year, y = mean_soilP_kg_ha, colour = scenario)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Simulation year",
    y = "Mean soil P in Hay HRUs (kg/ha)"
  ) +
  theme_bw()

ggplot(soilP_ws_40_all,
       aes(x = year, y = mean_soilP_kg_ha, colour = scenario)) +
  geom_line(linewidth = 1) +
  labs(
    x = "Simulation year",
    y = "Area-weighted mean soil P (kg/ha)"
  ) +
  theme_bw()

# Hay HRUs
ggplot(soilP_hay_40_all,
       aes(x = scenario, y = mean_soilP_kg_ha)) +
  geom_boxplot(outlier.alpha = 0.4) +
  labs(
    x = "Scenario",
    y = "Mean soil P in Hay HRUs (kg/ha, years 11–40)"
  ) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Whole watershed
ggplot(soilP_ws_40_all,
       aes(x = scenario, y = mean_soilP_kg_ha)) +
  geom_boxplot(outlier.alpha = 0.4) +
  labs(
    x = "Scenario",
    y = "Area-weighted mean soil P (kg/ha, years 11–40)"
  ) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
