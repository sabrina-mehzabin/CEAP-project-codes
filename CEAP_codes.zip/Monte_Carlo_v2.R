## ================================================================
##  SCRIPT A: MONTE CARLO 40-yr SWAT–VSA RUNS (NO SUMMARIES YET)
##  - Baseline + ALL BMP scenarios
##  - Runs in /scratch
##  - Does NOT delete run folders
##  - Saves a run index with status + parameters
## ================================================================

source("~/swat_LOC/R/readSWAT_3.R")

suppressPackageStartupMessages({
  library(fs)
  library(dplyr)
  library(purrr)
  library(lubridate)
  library(stringr)
  library(tidyr)
  library(lhs)
  library(parallel)
})

## ----------------------------------------------------------------
##  USER SETTINGS (ADJUST THESE ONLY)
## ----------------------------------------------------------------

baseline_template <- "~/copy_calib/calibfolderP_baseline_40yrWGN_new"
bmp_root40        <- "~/copy_calib/BMP_scenarios_final_feb26"
scratch_root <- file.path("/scratch", Sys.getenv("USER"), "MC3")

swat_exe          <- "~/new_swat/rev688_64rel_linux"

N_MC    <- 40      # realizations per scenario
n_cores <- 16       # parallel cores

## ----------------------------------------------------------------
##  PATHS & SCENARIO LIST
## ----------------------------------------------------------------

baseline_template <- path.expand(baseline_template)
bmp_root40        <- path.expand(bmp_root40)
scratch_root      <- path.expand(scratch_root)
swat_exe          <- path.expand(swat_exe)

if (!dir_exists(baseline_template)) stop("Baseline template not found: ", baseline_template)
if (!dir_exists(bmp_root40))       stop("BMP root folder not found: ", bmp_root40)
if (!file.exists(swat_exe))        stop("SWAT exe not found: ", swat_exe)

if (!dir_exists(scratch_root)) {
  dir_create(scratch_root, recurse = TRUE)
}

file.access("/scratch", 2)
file.access(file.path("/scratch", Sys.getenv("USER")), 2)


bmp_templates <- fs::dir_ls(
  bmp_root40,
  type    = "directory",
  recurse = FALSE
)

scen_templates <- tibble::tibble(
  scen_name    = c("Baseline", basename(bmp_templates)),
  template_dir = c(baseline_template, bmp_templates)
)

print(scen_templates)

run_root <- file.path(scratch_root, "MC_40yr_runs_safe")
if (dir_exists(run_root)) {
  stop("run_root already exists: ", run_root,
       "\nMove or delete this folder before starting a NEW MC run.")
}
dir_create(run_root, recurse = TRUE)

## ----------------------------------------------------------------
##  HELPER FUNCTIONS
## ----------------------------------------------------------------

copy_dir_recursive <- function(from, to) {
  from <- path.expand(from)
  to   <- path.expand(to)
  
  if (!dir_exists(from)) {
    stop("Template directory does not exist: ", from)
  }
  
  dir_create(dirname(to), recurse = TRUE)
  fs::dir_copy(from, to, overwrite = TRUE)
  invisible(TRUE)
}

resolve_bsn_path <- function(path) {
  path <- path.expand(path)
  if (dir.exists(path)) file.path(path, "basins.bsn") else path
}

read_basin_P_params <- function(path) {
  bsn_path <- resolve_bsn_path(path)
  if (!file.exists(bsn_path)) stop("basins.bsn not found at: ", bsn_path)
  
  lines <- readLines(bsn_path)
  get_val <- function(idx) {
    if (idx > length(lines)) stop("Line index ", idx, " not in basins.bsn")
    parts   <- strsplit(lines[idx], "\\|")[[1]]
    val_txt <- trimws(parts[1])
    as.numeric(val_txt)
  }
  
  tibble::tibble(
    PPERCO = get_val(31),
    PHOSKD = get_val(32),
    PSP    = get_val(33)
  )
}

write_basin_P_params <- function(run_dir,
                                 PHOSKD,
                                 PSP,
                                 PPERCO) {
  run_dir <- path.expand(run_dir)
  bsn_path <- file.path(run_dir, "basins.bsn")
  if (!file.exists(bsn_path)) stop("basins.bsn not found at: ", bsn_path)
  
  lines <- readLines(bsn_path)
  set_val <- function(idx, value) {
    if (idx > length(lines)) stop("Line index ", idx, " not in basins.bsn")
    parts <- strsplit(lines[idx], "\\|")[[1]]
    left  <- sprintf("%10.4f", value)
    if (length(parts) > 1) {
      lines[idx] <- paste0(left, " |", parts[2])
    } else {
      lines[idx] <- left
    }
  }
  set_val(31, PPERCO)
  set_val(32, PHOSKD)
  set_val(33, PSP)
  
  file.copy(bsn_path, paste0(bsn_path, ".MC_backup"), overwrite = TRUE)
  writeLines(lines, bsn_path, useBytes = TRUE)
  invisible(TRUE)
}

set_weather_seed <- function(run_dir, seed_val) {
  cio_path <- file.path(path.expand(run_dir), "file.cio")
  if (!file.exists(cio_path)) stop("file.cio not found in ", run_dir)
  
  lines <- readLines(cio_path)
  idx   <- grep("IGEN", lines, fixed = TRUE)
  if (!length(idx)) stop("IGEN not found in file.cio in ", run_dir)
  i <- idx[1]
  
  parts <- strsplit(lines[i], "\\|")[[1]]
  left  <- sprintf("%10d", as.integer(seed_val))
  if (length(parts) > 1) {
    lines[i] <- paste0(left, " |", parts[2])
  } else {
    lines[i] <- left
  }
  
  file.copy(cio_path, paste0(cio_path, ".MCbackup"), overwrite = TRUE)
  writeLines(lines, cio_path, useBytes = TRUE)
  invisible(TRUE)
}

run_swat_generic <- function(run_dir,
                             swat_exe) {
  run_dir  <- path.expand(run_dir)
  swat_exe <- path.expand(swat_exe)
  
  if (!dir_exists(run_dir))   stop("run_dir not found: ", run_dir)
  if (!file.exists(swat_exe)) stop("SWAT exe not found: ", swat_exe)
  
  old_wd <- getwd()
  on.exit(setwd(old_wd), add = TRUE)
  setwd(run_dir)
  
  message("Cleaning old output files in ", run_dir, " …")
  old_out <- list.files(pattern = "^output\\.")
  if (length(old_out)) file.remove(old_out)
  
  message("Running SWAT in ", run_dir, " …")
  system(shQuote(swat_exe), intern = FALSE)
  
  new_out <- list.files(pattern = "^output\\.")
  if (!length(new_out)) stop("SWAT produced no output files in ", run_dir)
  
  message("SWAT run completed ✔ in ", run_dir)
  invisible(new_out)
}

## ----------------------------------------------------------------
##  LATIN HYPERCUBE SAMPLING
## ----------------------------------------------------------------

base_pars <- read_basin_P_params(baseline_template)
print(base_pars)

set.seed(1234)
lhs_raw <- randomLHS(N_MC, 3)  # PHOSKD, PSP, PPERCO

phoskd_mult <- 0.5 + lhs_raw[, 1]
psp_mult    <- 0.5 + lhs_raw[, 2]
pperco_mult <- 0.5 + lhs_raw[, 3]

param_samples <- tibble::tibble(
  mc_id        = 1:N_MC,
  PHOSKD       = base_pars$PHOSKD * phoskd_mult,
  PSP          = base_pars$PSP    * psp_mult,
  PPERCO       = base_pars$PPERCO * pperco_mult,
  seed_weather = sample.int(1e6, N_MC)
)

print(head(param_samples, 5))

## ----------------------------------------------------------------
##  ONE REALIZATION (ONLY RUN, NO SUMMARIES, NO CLEANUP)
## ----------------------------------------------------------------

run_one_realization <- function(scen_name, template_dir, mc_row) {
  mc_id        <- mc_row$mc_id
  PHOSKD_val   <- mc_row$PHOSKD
  PSP_val      <- mc_row$PSP
  PPERCO_val   <- mc_row$PPERCO
  seed_weather <- mc_row$seed_weather
  
  scen_run_root <- file.path(run_root, scen_name)
  dir_create(scen_run_root, recurse = TRUE)
  
  run_dir <- file.path(scen_run_root, sprintf("mc_%03d", mc_id))
  
  message("\n--- Scenario ", scen_name, " | MC ", mc_id, " ---")
  message("Run dir: ", run_dir)
  
  copy_dir_recursive(template_dir, run_dir)
  
  write_basin_P_params(
    run_dir,
    PHOSKD = PHOSKD_val,
    PSP    = PSP_val,
    PPERCO = PPERCO_val
  )
  set_weather_seed(run_dir, seed_val = seed_weather)
  
  run_swat_generic(run_dir, swat_exe = swat_exe)
  
  tibble::tibble(
    scen_name    = scen_name,
    mc_id        = mc_id,
    run_dir      = run_dir,
    PHOSKD       = PHOSKD_val,
    PSP          = PSP_val,
    PPERCO       = PPERCO_val,
    seed_weather = seed_weather,
    status       = "ok",
    error_msg    = NA_character_
  )
}

safe_run_one <- function(scen_name, template_dir, mc_row) {
  tryCatch(
    run_one_realization(scen_name, template_dir, mc_row),
    error = function(e) {
      message("ERROR in ", scen_name, " MC ", mc_row$mc_id, ": ", e$message)
      tibble::tibble(
        scen_name    = scen_name,
        mc_id        = mc_row$mc_id,
        run_dir      = file.path(run_root, scen_name,
                                 sprintf("mc_%03d", mc_row$mc_id)),
        PHOSKD       = mc_row$PHOSKD,
        PSP          = mc_row$PSP,
        PPERCO       = mc_row$PPERCO,
        seed_weather = mc_row$seed_weather,
        status       = "error",
        error_msg    = as.character(e$message)
      )
    }
  )
}

## ----------------------------------------------------------------
##  MAIN LOOP OVER SCENARIOS (PARALLEL MC)
## ----------------------------------------------------------------

MC_run_index <- list()

for (i in seq_len(nrow(scen_templates))) {
  scen_name    <- scen_templates$scen_name[i]
  template_dir <- scen_templates$template_dir[i]
  
  message("\n==============================")
  message("Starting scenario: ", scen_name)
  message("==============================\n")
  
  res_list <- mclapply(
    X        = 1:nrow(param_samples),
    FUN      = function(j) {
      safe_run_one(
        scen_name    = scen_name,
        template_dir = template_dir,
        mc_row       = param_samples[j, ]
      )
    },
    mc.cores = n_cores
  )
  
  scen_index <- bind_rows(res_list)
  MC_run_index[[scen_name]] <- scen_index
  
  saveRDS(
    scen_index,
    file = file.path(run_root,
                     paste0("MC_runIndex_40yr_", scen_name, ".rds"))
  )
}

MC_run_index_df <- bind_rows(MC_run_index)

saveRDS(
  MC_run_index_df,
  file = file.path(run_root, "MC_runIndex_40yr_allScenarios.rds")
)

message("\nALL SCENARIOS COMPLETED (or attempted).")
message("Run index saved in: ", run_root)



############################

## ================================================================
##  SCRIPT B: POST-PROCESS MC RUNS (Soil P + TP metrics)
## ================================================================

source("~/swat_LOC/R/readSWAT_3.R")

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(lubridate)
  library(fs)
})

# Must match SCRIPT A
scratch_root <- "/scratch/sabrinam21_MC1"
run_root     <- file.path(scratch_root, "MC_40yr_runs_safe")

MC_run_index_df <- readRDS(file.path(run_root, "MC_runIndex_40yr_allScenarios.rds"))

# Keep only runs that succeeded
MC_ok <- MC_run_index_df %>%
  filter(status == "ok")

nrow(MC_ok)   # should be close to N_MC * number_of_scenarios


## ---- helper: prep_snu_joined / soilP / TP (same as before) ----

prep_snu_joined <- function(run_dir) {
  hru <- readSWAT("hru", run_dir)
  snu <- readSWAT("snu", run_dir)
  
  snu <- snu %>% rename(GIS = GISnum)
  
  hru_keep <- hru %>%
    select(mdate, HRU, LULC, AREAkm2, GIS)
  
  snu_joined <- snu %>%
    left_join(hru_keep, by = c("mdate", "GIS")) %>%
    mutate(
      mdate       = as.Date(mdate),
      year        = lubridate::year(mdate),
      soilP_kg_ha = SOL_P + ORG_P
    )
  
  list(hru = hru, snu_joined = snu_joined)
}

hay_soilP_table <- function(run_dir) {
  obj        <- prep_snu_joined(run_dir)
  snu_joined <- obj$snu_joined
  
  hay_snu <- snu_joined %>%
    filter(LULC == "ORCD")
  
  if (nrow(hay_snu) == 0) {
    return(NULL)
  }
  
  hay_year_end <- hay_snu %>%
    group_by(HRU, year) %>%
    filter(mdate == max(mdate)) %>%
    slice_tail(n = 1) %>%
    ungroup() %>%
    select(HRU, year, soilP_kg_ha)
  
  hay_legacy_table <- hay_year_end %>%
    pivot_wider(names_from = year, values_from = soilP_kg_ha) %>%
    arrange(HRU)
  
  hay_legacy_table
}

summarise_soilP_longterm <- function(run_dir) {
  tbl <- hay_soilP_table(run_dir)
  if (is.null(tbl) || nrow(tbl) == 0) {
    return(tibble(
      mean_soilP_start = NA_real_,
      mean_soilP_end   = NA_real_,
      mean_soilP_delta = NA_real_
    ))
  }
  
  year_cols <- setdiff(names(tbl), "HRU")
  years_num <- sort(as.integer(year_cols))
  start_col <- as.character(min(years_num))
  end_col   <- as.character(max(years_num))
  
  tbl <- tbl %>%
    mutate(
      soilP_start = .data[[start_col]],
      soilP_end   = .data[[end_col]],
      soilP_delta = soilP_end - soilP_start
    )
  
  tbl %>%
    summarise(
      mean_soilP_start = mean(soilP_start, na.rm = TRUE),
      mean_soilP_end   = mean(soilP_end,   na.rm = TRUE),
      mean_soilP_delta = mean(soilP_delta, na.rm = TRUE)
    )
}

summarise_TP_longterm <- function(run_dir, outlet_rch = 3, warmup_years = 10) {
  rch <- readSWAT("rch", run_dir) %>%
    filter(RCH == outlet_rch) %>%
    mutate(year = lubridate::year(mdate))
  
  years <- sort(unique(rch$year))
  if (length(years) <= warmup_years) {
    return(tibble(mean_TP_load_kg = NA_real_))
  }
  analysis_years <- years[(warmup_years + 1):length(years)]
  
  annual <- rch %>%
    filter(year %in% analysis_years) %>%
    group_by(year) %>%
    summarise(
      TP_load_kg = sum(TOT_Pkg, na.rm = TRUE),
      .groups = "drop"
    )
  
  annual %>%
    summarise(mean_TP_load_kg = mean(TP_load_kg, na.rm = TRUE))
}

## ---- safe wrapper for one run_dir ----

summarise_one_run <- function(row) {
  run_dir <- row$run_dir
  
  tryCatch(
    {
      soilP_stats <- summarise_soilP_longterm(run_dir)
      TP_stats    <- summarise_TP_longterm(run_dir)
      
      tibble::tibble(
        scen_name        = row$scen_name,
        mc_id            = row$mc_id,
        PHOSKD           = row$PHOSKD,
        PSP              = row$PSP,
        PPERCO           = row$PPERCO,
        seed_weather     = row$seed_weather,
        mean_soilP_start = soilP_stats$mean_soilP_start,
        mean_soilP_end   = soilP_stats$mean_soilP_end,
        mean_soilP_delta = soilP_stats$mean_soilP_delta,
        mean_TP_load_kg  = TP_stats$mean_TP_load_kg
      )
    },
    error = function(e) {
      message("POST error in ", row$scen_name, " mc_", sprintf("%03d", row$mc_id),
              ": ", e$message)
      tibble::tibble(
        scen_name        = row$scen_name,
        mc_id            = row$mc_id,
        PHOSKD           = row$PHOSKD,
        PSP              = row$PSP,
        PPERCO           = row$PPERCO,
        seed_weather     = row$seed_weather,
        mean_soilP_start = NA_real_,
        mean_soilP_end   = NA_real_,
        mean_soilP_delta = NA_real_,
        mean_TP_load_kg  = NA_real_
      )
    }
  )
}

## ---- loop (parallel) over all successful runs ----

n_cores <- 16

rows_list <- split(MC_ok, seq_len(nrow(MC_ok)))

res_list <- parallel::mclapply(
  X        = rows_list,
  FUN      = function(x) summarise_one_run(x[1, ]),
  mc.cores = n_cores
)

MC_results_df <- bind_rows(res_list)

saveRDS(
  MC_results_df,
  file = file.path(run_root, "MC_results_40yr_allScenarios_postProcessed.rds")
)

message("\nPost-processing completed. Results saved in:\n", run_root)

########################

suppressPackageStartupMessages({
  library(fs)
  library(dplyr)
  library(purrr)
})



library(fs)

run_root <- "/scratch/sabrinam21_MC1/MC_40yr_runs_safe"  # or "MC_40yr_runs"
fs::dir_ls(run_root, type = "directory", recurse = FALSE)
