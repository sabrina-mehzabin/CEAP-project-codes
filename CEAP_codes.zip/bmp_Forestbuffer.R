library(sf)
library(dplyr)
library(readr)

# 1) Read the shapefiles
hru <- st_read("~/copy_calib/hru/hru1.shp")       # has HRU_ID, HRU_GIS, geometry
riv <- st_read("~/copy_calib/reach/wdreach.shp")  # your stream network

# 2) Read the HRU attributes that include LANDUSE
hru_attr <- read_csv("~/copy_calib/HAY.csv")
# e.g. columns: SUBBASIN, HRU, LANDUSE, SLOPE, SOIL, ...

# 3) Join LANDUSE onto the shapefile using HRU ID
hru_joined <- hru %>%
  left_join(hru_attr, by = c("HRU_ID" = "HRU"))

names(hru_joined)
table(hru_joined$LANDUSE)

hru_hay <- hru_joined %>%
  filter(LANDUSE == "HAY")
nrow(hru_hay)   # should now be > 0

idx_near <- sf::st_is_within_distance(hru_hay, riv, dist = 100, sparse = FALSE)

near_hay_100m <- hru_hay[apply(idx_near, 1, any), ]
near_hay_100m_ids <- near_hay_100m$HRU_ID
near_hay_100m_ids

near_hay_100m_ids_u <- sort(unique(near_hay_100m_ids))
near_hay_100m_ids_u

plot(st_geometry(riv), col="blue", lwd=2)
plot(st_geometry(hru[hru$HRU_ID %in% near_hay_100m_ids_u, ]), add=TRUE, col="red")

near_stream_hay_table <- hru_attr[hru_attr$HRU_ID %in% near_hay_100m_ids_u, ]

write.csv(near_stream_hay_table,
          "near_stream_HAY_HRUs_100m.csv",
          row.names = FALSE)


#################

##############################################################################
# BMP: ForestBuffer10m
# - Start from P-calibrated baseline
# - Copy to BMP_scenarios/ForestBuffer10m
# - On near-stream HAY HRUs (near_hay_100m_ids_u):
#     * Set FILTERW = 10.0 m
##############################################################################

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(stringr)
})

## ---------- USER INPUT -----------------------------------------------------

#1) P-calibrated baseline (already has your final .mgt schedules)
baselineP_dir  <- "~/copy_calib/P_calibrated2"

# 2) Folder where BMP scenarios live
bmp_root       <- "~/copy_calib/BMP_scenarios_final"

# 3) Scenario name for this BMP
scenario_name  <- "ForestBuffer10m"
scenario_dir   <- file.path(bmp_root, scenario_name)

# 1) Use the NEW 40-yr baseline with weather generator
baselineP_dir  <- "~/copy_calib/calibfolderP_baseline_40yrWGN_new"

# 2) (Recommended) keep 40-yr BMPs separate from old 8-yr BMPs
bmp_root       <- "~/copy_calib/BMP_scenarios_40yr_new"

scenario_name  <- "ForestBuffer10m"
scenario_dir   <- file.path(bmp_root, scenario_name)


# 4) HRUs that should receive the forest buffer (10 m)
#    This vector must already exist from your sf analysis:
#    near_hay_100m_ids_u <- sort(unique(near_hay_100m_ids))
buffer_hrus    <- near_hay_100m_ids_u

# 5) Buffer strip width (m)
buffer_width_m <- 10.0

## ---------- PREP & COPY BASELINE -------------------------------------------

baselineP_dir <- path.expand(baselineP_dir)
scenario_dir  <- path.expand(scenario_dir)

if (!dir.exists(baselineP_dir)) {
  stop("baselineP_dir not found: ", baselineP_dir)
}

dir.create(scenario_dir, recursive = TRUE, showWarnings = FALSE)

# Copy CONTENTS of baseline directory into scenario_dir
baseline_files <- list.files(baselineP_dir, full.names = TRUE, recursive = TRUE)

for (src in baseline_files) {
  # path relative to baselineP_dir
  rel  <- sub(paste0("^", baselineP_dir, "/"), "", src)
  dest <- file.path(scenario_dir, rel)
  dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
  file.copy(src, dest, overwrite = TRUE)
}

cat("Baseline copied into scenario directory:\n  ", scenario_dir, "\n")

library(readr)
library(stringr)

# --- 1. HRUs to receive forest buffer ---------------------------------------

buffer_hrus <- as.integer(near_hay_100m_ids_u)   # or manually: c(5, 6, 7, ...)

buffer_width_m <- 10  # 10-m buffer

# --- 2. Re-use the original HRU parser (FIRST "HRU:" in header) -------------

parse_hru_id_from_mgt <- function(fp) {
  first_line <- readr::read_lines(fp, n_max = 1)
  hru_token  <- stringr::str_extract(first_line, "HRU:\\s*\\d+")
  if (is.na(hru_token)) return(NA_integer_)
  as.integer(stringr::str_extract(hru_token, "\\d+"))
}

# --- 3. Update FILTERW line --------------------------------------------------

update_filterw_line <- function(lines, new_width_m) {
  idx <- grep("\\bFILTERW\\b", lines)
  if (!length(idx)) return(lines)
  
  i   <- idx[1]
  old <- lines[i]
  
  # Replace the numeric value but KEEP spacing before '|'
  lines[i] <- sub(
    pattern = "^(\\s*)([-0-9.+Ee]+)(\\s*\\|\\s*FILTERW)",
    replacement = sprintf("\\1%.2f    \\3", new_width_m),
    x = old
  )
  
  lines
}


edit_mgt_file_buffer <- function(mgt_path, buffer_width_m) {
  lines <- readLines(mgt_path, warn = FALSE)
  if (!length(lines)) return(invisible(FALSE))
  
  lines_new <- update_filterw_line(lines, buffer_width_m)
  
  if (!identical(lines, lines_new)) {
    bak <- paste0(mgt_path, ".ForestBuffer10m.bak")
    file.copy(mgt_path, bak, overwrite = TRUE)
    writeLines(lines_new, mgt_path, useBytes = TRUE)
    return(invisible(TRUE))
  }
  invisible(FALSE)
}

# --- 4. Loop through .mgt files in the scenario -----------------------------

mgt_files <- list.files(
  scenario_dir,
  pattern = "^[^.].*\\.mgt$",
  full.names = TRUE,
  recursive = TRUE
)

count_edit <- 0L

for (fp in mgt_files) {
  hru_id <- parse_hru_id_from_mgt(fp)
  if (hru_id %in% buffer_hrus) {
    lines <- readLines(fp)
    lines_new <- update_filterw_line(lines, buffer_width_m)
    if (!identical(lines, lines_new)) {
      file.copy(fp, paste0(fp, ".fix.bak"), overwrite = TRUE)
      writeLines(lines_new, fp, useBytes = TRUE)
      count_edit <- count_edit + 1
    }
  }
}

cat("Fixed files:", count_edit, "\n")

cat("\nBMP ForestBuffer10m summary:",
    "\n  .mgt files edited (near-stream HAY HRUs): ", count_edit,
    "\n  .mgt files skipped:                      ", count_skip,
    "\n  Scenario directory:                      ", scenario_dir, "\n\n")

## ---------- RUN SWAT IN ForestBuffer10m SCENARIO ---------------------------

pacman::p_load(SWATmodel,dplyr,EcoHydRology,base,topmodel,utils, lubridate,stringr,diffobj,tidyr,rnoaa,readr,ggplot2)
run_swat <- function(swat_exe  = "~/new_swat/rev688_64rel_linux",
                     work_dir  = scenario_dir) {
  
  swat_exe <- path.expand(swat_exe)
  work_dir <- path.expand(work_dir)
  
  if (!file.exists(swat_exe)) stop("SWAT executable not found: ", swat_exe)
  if (!dir.exists(work_dir))  stop("Working dir not found: ", work_dir)
  
  setwd(work_dir)
  
  message("Cleaning old output files …")
  old_out <- list.files(pattern = "output\\.")
  if (length(old_out)) file.remove(old_out)
  
  message("Running SWAT in ForestBuffer10m …")
  system(shQuote(swat_exe), intern = FALSE)
  
  new_out <- list.files(pattern = "output\\.")
  if (length(new_out)) {
    message("SWAT run completed ✔")
    return(new_out)
  } else {
    stop("SWAT produced no output files in scenario_dir.")
  }
}

# ── run it ───────────────────────────────────────────────────────────────────
output_files <- run_swat()
cat("Generated output files in ForestBuffer10m:\n"); print(output_files)


## ---------- READ OUTPUT & CALCULATE EVENT TP -------------------------------

myhomedir = Sys.getenv("HOME")
basedir   = myhomedir
codedir   = paste0(basedir, "/swat_LOC/R")

source(file.path(codedir, "readSWAT_3.R"))
save(readSWAT, file = "readSWAT.R")

# 5. Read output.rch and keep reach 3
load("readSWAT.R")
outdata  <- readSWAT("rch", ".")
rch_data <- subset(outdata, RCH == 3)
rch_data$Date <- rch_data$mdate

# 6. Read event definitions + observed loads
Events <- read.csv("Events.csv")
Events$start_date <- as.Date(Events$start_date, "%m/%d/%Y")
Events$end_date   <- as.Date(Events$end_date,   "%m/%d/%Y")

# 7. Aggregate simulated TP per event (kg)
sim_P <- numeric(nrow(Events))
for (i in seq_len(nrow(Events))) {
  ev <- subset(rch_data,
               Date >= Events$start_date[i] &
                 Date <= Events$end_date[i])
  sim_P[i] <- sum(ev$TOT_Pkg, na.rm = TRUE)
}
Events$Total_P_simulated <- sim_P


## ---------- PLOT SIMULATED VS OBSERVED -------------------------------------

library(ggplot2)

ggplot(Events, aes(x = end_date)) +
  geom_line(aes(y = Total_P_simulated, color = "Simulated"), size = 2, alpha = 0.9) +
  geom_line(aes(y = Tot_P,             color = "Observed"),  size = 2, alpha = 0.9) +
  labs(
    x = "Time",
    y = "Total P (kg)",
    color = ""
  ) +
  scale_color_manual(
    values = c("Simulated" = "magenta", "Observed" = "orange")
  ) +
  theme_minimal(base_size = 15) +
  theme(
    plot.title  = element_text(size = 16, hjust = 0.5),
    axis.title  = element_text(size = 15),
    axis.text   = element_text(size = 13),
    panel.border = element_rect(color = "black", fill = NA, size = 1),
    plot.margin  = margin(t = 5, r = 25, b = 5, l = 5, unit = "pt")
  )


