##############################################################################
# Multi-BMP Suite: Winter Rye + NM80 Nutrient Mgmt + 10m Forest Buffer
#
# - Start from P-calibrated baseline: calibfolderP_baseline
# - Copy to BMP_scenarios/MultiBMP_Rye_NM80_Buffer
# - Apply, in this order:
#    (1) Cover crop (winter rye) on CornFromHay HRUs (and baseline hay rotation)
#    (2) Nutrient management (NM80 + manure injection) on Hay/CornFromHay HRUs
#    (3) 10-m forest buffer (FILTERW) on near-stream Hay HRUs
#
# Assumptions:
#   * soilP_init_mapping_for_mgt.csv in baselineP_dir has HRU_ID + group
#       group == "Hay" or "CornFromHay"
#   * near_hay_100m_ids_u (vector of HRU_IDs) already exists in your R session
#   * readSWAT_3.R is in ~/swat_LOC/R
##############################################################################

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(stringr)
})

## ---------- USER INPUT -----------------------------------------------------

# # 1) P-calibrated baseline directory
# baselineP_dir <- "~/copy_calib/calibfolderP_baseline"
# 
# # 2) BMP scenario root and *new* multi-BMP scenario name
# bmp_root      <- "~/copy_calib/BMP_scenarios_final"
# scenario_name <- "MultiBMP_Rye_NM80_Buffer"
# scenario_dir  <- file.path(bmp_root, scenario_name)

# 1) Use the NEW 40-yr baseline with weather generator
baselineP_dir  <- "~/copy_calib/calibfolderP_baseline_40yrWGN"

# 2) (Recommended) keep 40-yr BMPs separate from old 8-yr BMPs
bmp_root       <- "~/copy_calib/BMP_scenarios_40yr"

scenario_name  <- "MultiBMP_Rye_NM80_Buffer"
scenario_dir   <- file.path(bmp_root, scenario_name)


# 3) Soil-P mapping file (contains HRU_ID, LUSE, group, init_ppm)
mapping_csv   <- file.path(baselineP_dir, "soilP_init_mapping_for_mgt.csv")

# 4) Near-stream hay HRUs for buffer (already created via sf)
buffer_hrus   <- as.integer(near_hay_100m_ids_u)

# 5) Winter rye parameters
RYE_PLANT_ID   <- 5        # from your crop.dat
RYE_HEAT_UNITS <- 1000.0   # can be tuned

# 6) Rotation recipes per cohort (same as Script B)
rotation_for_hay_cohort  <- c(hay = 4, corn = 2, hay = 2)
rotation_for_corn_cohort <- c(corn = 6, hay = 2)

# 7) Nutrient management settings (commercial 80%, manure injected)
P_mult          <- 0.80
manure_fert_ids <- c(53L)

# 8) Buffer strip width (m)
buffer_width_m <- 10.0

TOTAL_COLS <- 100

## ---------- PREP & COPY BASELINE -------------------------------------------

baselineP_dir <- path.expand(baselineP_dir)
scenario_dir  <- path.expand(scenario_dir)

if (!dir.exists(baselineP_dir)) {
  stop("baselineP_dir not found: ", baselineP_dir)
}

dir.create(scenario_dir, recursive = TRUE, showWarnings = FALSE)

baseline_files <- list.files(baselineP_dir, full.names = TRUE, recursive = TRUE)

for (src in baseline_files) {
  rel  <- sub(paste0("^", baselineP_dir, "/"), "", src)
  dest <- file.path(scenario_dir, rel)
  dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
  file.copy(src, dest, overwrite = TRUE)
}

cat("Baseline copied into multi-BMP scenario:\n  ", scenario_dir, "\n")

## ---------- LOAD HAY / CORN SPLIT ------------------------------------------

if (!file.exists(mapping_csv)) {
  stop("soilP_init_mapping_for_mgt.csv not found at: ", mapping_csv)
}

mapping <- read_csv(mapping_csv, show_col_types = FALSE) %>%
  mutate(
    HRU_ID = as.integer(HRU_ID),
    group  = trimws(group)
  )

hay_hrus  <- mapping %>% filter(group == "Hay")         %>% pull(HRU_ID) %>% unique()
corn_hrus <- mapping %>% filter(group == "CornFromHay") %>% pull(HRU_ID) %>% unique()

bmp_hru_ids <- c(hay_hrus, corn_hrus) %>% unique()

cat("HRUs by group from mapping:",
    "\n  Hay HRUs:         ", length(hay_hrus),
    "\n  CornFromHay HRUs: ", length(corn_hrus),
    "\n  All BMP HRUs:     ", length(bmp_hru_ids), "\n")

## ---------- GENERIC HELPERS ------------------------------------------------

parse_hru_id_from_mgt <- function(fp) {
  first_line <- readr::read_lines(fp, n_max = 1)
  hru_token  <- stringr::str_extract(first_line, "HRU:\\s*\\d+")
  if (is.na(hru_token)) return(NA_integer_)
  as.integer(stringr::str_extract(hru_token, "\\d+"))
}

parse_int <- function(line, start, end) {
  as.integer(trimws(substr(line, start, end)))
}

parse_num <- function(line, start, end) {
  as.numeric(trimws(substr(line, start, end)))
}

## ==========================================================================##
##  (1) COVER CROP (WINTER RYE) – REBUILD OPERATION SCHEDULES (S2 LOGIC)    ##
## ==========================================================================##

fixed_line <- function(specs, total_cols = TOTAL_COLS) {
  buf <- strrep(" ", total_cols)
  for (i in seq_len(nrow(specs))) {
    s <- sprintf(specs$fmt[i], specs$val[i])
    w <- specs$width[i]
    if (nchar(s) < w) s <- sprintf(paste0("%", w, "s"), s)
    if (nchar(s) > w) s <- substr(s, 1, w)
    substr(buf, specs$col[i], specs$col[i] + w - 1) <- s
  }
  buf
}

common_prefix_specs <- function(month, day, mgt_op, husc = 0) {
  data.frame(
    name  = c("MONTH","DAY","HUSC","MGT_OP"),
    col   = c(2,       5,     8,     17),
    width = c(2,       2,     8,      2),
    fmt   = c("%02d","%02d","%8.3f","%2d"),
    val   = c(month,   day,   husc,   mgt_op),
    stringsAsFactors = FALSE
  )
}

build_tillage <- function(month, day, TILL_ID, husc = 0) {
  spec <- common_prefix_specs(month, day, 6, husc)
  spec2 <- rbind(spec, data.frame(name="TILL_ID", col=20, width=4,
                                  fmt="%4d", val=TILL_ID))
  fixed_line(spec2)
}

build_fertilizer <- function(month, day, FERT_ID, FERT_KG, FRT_SURFACE, husc = 0) {
  if (is.character(FERT_KG)) FERT_KG <- as.numeric(gsub(",", "", FERT_KG))
  spec <- common_prefix_specs(month, day, 3, husc)
  spec2 <- rbind(
    spec,
    data.frame(name="FERT_ID",     col=20, width=4,  fmt="%4d",     val=FERT_ID),
    data.frame(name="FERT_KG",     col=32, width=12, fmt="%12.5f",  val=FERT_KG),
    data.frame(name="FRT_SURFACE", col=45, width=6,  fmt="%6.2f",   val=FRT_SURFACE)
  )
  fixed_line(spec2)
}

build_planting <- function(month, day, PLANT_ID, HEAT_UNITS, husc = 0) {
  spec <- common_prefix_specs(month, day, 1, husc)
  spec2 <- rbind(
    spec,
    data.frame(name="PLANT_ID",   col=20, width=4,  fmt="%4d",     val=PLANT_ID),
    data.frame(name="HEAT_UNITS", col=32, width=12, fmt="%12.5f",  val=HEAT_UNITS)
  )
  fixed_line(spec2)
}

build_harvest <- function(month, day, HARVEFF = 1.0, husc = 0) {
  spec <- common_prefix_specs(month, day, 7, husc)
  spec2 <- rbind(spec, data.frame(name="HARVEFF", col=32, width=12,
                                  fmt="%12.5f", val=HARVEFF))
  fixed_line(spec2)
}

build_kill <- function(month, day, husc = 0) {
  spec <- common_prefix_specs(month, day, 8, husc)
  fixed_line(spec)
}

build_year_end <- function(month = 12, day = 31, husc = 0) {
  spec <- common_prefix_specs(month, day, 0, husc)
  fixed_line(spec)
}

# HAY one-year schedule (baseline)
hay_schedule_one_year <- function() {
  c(
    build_planting  (5, 1,  PLANT_ID=4, HEAT_UNITS=1200.0),
    build_fertilizer(5, 2,  FERT_ID=54, FERT_KG="168.127",  FRT_SURFACE=1.00),
    build_harvest   (6, 1,  HARVEFF=1.0),
    build_harvest   (7, 15, HARVEFF=1.0),
    build_fertilizer(7, 16, FERT_ID=53, FERT_KG="842.0",    FRT_SURFACE=1.00),
    build_harvest   (8, 30, HARVEFF=1.0),
    build_fertilizer(9, 1,  FERT_ID=53, FERT_KG="842.0",    FRT_SURFACE=1.00),
    build_year_end  (12, 31, husc = 0)
  )
}

# CORN one-year schedule with winter rye
corn_schedule_one_year <- function() {
  c(
    build_kill      (4, 15),
    build_tillage   (5, 10, TILL_ID=61),
    build_fertilizer(5, 15, FERT_ID=54, FERT_KG="112.085",  FRT_SURFACE=1.00),
    build_planting  (5, 15, PLANT_ID=4, HEAT_UNITS=1800.0),
    build_fertilizer(7, 10, FERT_ID=54, FERT_KG="266.302",  FRT_SURFACE=1.00),
    build_harvest   (10, 1, HARVEFF=0.01),
    build_kill      (10, 1),
    build_fertilizer(10,10, FERT_ID=53, FERT_KG="2806.200", FRT_SURFACE=1.00),
    build_tillage   (10,15, TILL_ID=57),
    build_planting  (10,20, PLANT_ID = RYE_PLANT_ID,
                     HEAT_UNITS = RYE_HEAT_UNITS),
    build_year_end  (12, 31, husc = 0)
  )
}

.schedule_map <- list(hay = hay_schedule_one_year,
                      corn = corn_schedule_one_year)

build_rotation_schedule <- function(rotation_vec) {
  stopifnot(length(rotation_vec) > 0, !is.null(names(rotation_vec)))
  lines <- character(0); total_years <- 0L
  for (k in seq_along(rotation_vec)) {
    crop <- names(rotation_vec)[k]; yrs <- as.integer(rotation_vec[[k]])
    if (!crop %in% names(.schedule_map)) stop("Unknown crop key: ", crop)
    one_year <- .schedule_map[[crop]]()
    for (i in seq_len(yrs)) lines <- c(lines, one_year)
    total_years <- total_years + yrs
  }
  attr(lines, "nrot") <- total_years
  lines
}

mgt_set_nrot <- function(lines, nrot) {
  ix <- grep("\\|\\s*NROT\\b", lines, perl = TRUE)
  if (!length(ix)) stop("NROT line not found.")
  tgt <- ix[1]
  lines[tgt] <- sub("^\\s*[-+]?[0-9]*\\.?\\d+",
                    as.character(as.integer(nrot)), lines[tgt])
  lines
}

replace_operation_schedule <- function(lines, new_schedule_lines) {
  start <- grep("^\\s*Operation\\s+Schedule:", lines)
  if (!length(start)) stop("'Operation Schedule:' line not found.")
  start <- start[1]
  after <- start + 1L
  while (after <= length(lines) &&
         nzchar(trimws(lines[after])) &&
         !grepl("^\\s*[A-Za-z].*:\\s*$", lines[after])) {
    after <- after + 1L
  }
  if (after > length(lines)) {
    c(lines[1:start], new_schedule_lines)
  } else {
    c(lines[1:start], new_schedule_lines, lines[after:length(lines)])
  }
}

.parse_field <- function(line, start, end) {
  as.integer(gsub("\\s+", "", substr(line, start, end)))
}

validate_ops <- function(op_lines, total_cols = TOTAL_COLS) {
  ok <- TRUE; problems <- list()
  for (i in seq_along(op_lines)) {
    L <- op_lines[[i]]
    if (nchar(L, "bytes") != total_cols) {
      ok <- FALSE; problems[[length(problems)+1]] <-
        paste0("Line ", i, ": width=", nchar(L, "bytes"))
      next
    }
    mm <- .parse_field(L, 2, 3)
    dd <- .parse_field(L, 5, 6)
    if (is.na(mm) || mm < 1 || mm > 12)
    {ok <- FALSE; problems[[length(problems)+1]] <- paste0("Line ", i, ": bad MONTH=", mm)}
    if (is.na(dd) || dd < 1 || dd > 31)
    {ok <- FALSE; problems[[length(problems)+1]] <- paste0("Line ", i, ": bad DAY=", dd)}
    op <- .parse_field(L, 17, 18)
    if (is.na(op) || !(op %in% c(0,1,3,6,7,8,17)))
    {ok <- FALSE; problems[[length(problems)+1]] <- paste0("Line ", i, ": bad MGT_OP=", op)}
  }
  list(ok = ok, problems = problems)
}

count_year_ends <- function(op_lines) {
  sum(vapply(op_lines,
             function(L) .parse_field(L, 17, 18) == 0L,
             logical(1)))
}

update_mgt_file <- function(mgt_path, schedule_lines, nrot) {
  chk <- validate_ops(schedule_lines, total_cols = TOTAL_COLS)
  if (!chk$ok) stop(paste(c("Validation failed:",
                            unlist(chk$problems)), collapse = "\n"))
  if (count_year_ends(schedule_lines) != nrot) {
    stop("NROT mismatch between rotation years and MGT_OP=0 count.")
  }
  
  old <- readLines(mgt_path, warn = FALSE)
  new <- old
  new <- mgt_set_nrot(new, nrot)
  new <- replace_operation_schedule(new, schedule_lines)
  
  if (!identical(old, new)) {
    bak <- paste0(mgt_path, ".MultiBMP_Rye.bak")
    writeLines(old, bak, useBytes = TRUE)
    writeLines(new, mgt_path, useBytes = TRUE)
  }
  invisible(TRUE)
}

update_mgt_file_with_rotation <- function(mgt_path, rotation_vec) {
  sched <- build_rotation_schedule(rotation_vec)
  nrot  <- attr(sched, "nrot")
  update_mgt_file(mgt_path, sched, nrot)
}

## Apply winter rye schedules first
mgt_files <- list.files(scenario_dir,
                        pattern = "^[^.].*\\.mgt$",
                        full.names = TRUE,
                        recursive = TRUE)

count_hay  <- 0L
count_corn <- 0L
count_skip <- 0L

for (fp in mgt_files) {
  hru_id <- parse_hru_id_from_mgt(fp)
  if (is.na(hru_id)) {
    count_skip <- count_skip + 1L
    next
  }
  
  if (hru_id %in% hay_hrus) {
    update_mgt_file_with_rotation(fp, rotation_for_hay_cohort)
    count_hay <- count_hay + 1L
  } else if (hru_id %in% corn_hrus) {
    update_mgt_file_with_rotation(fp, rotation_for_corn_cohort)
    count_corn <- count_corn + 1L
  } else {
    count_skip <- count_skip + 1L
  }
}

cat("\n(1) Winter Rye schedules applied:",
    "\n  Hay HRUs edited:         ", count_hay,
    "\n  CornFromHay HRUs edited: ", count_corn,
    "\n  .mgt files skipped:      ", count_skip, "\n")

## ==========================================================================##
##  (2) NUTRIENT MANAGEMENT (NM80 + MANURE INJECTION) – ON HAY/CORN HRUs     ##
## ==========================================================================##

update_fert_line_nm80 <- function(line, P_mult, manure_ids) {
  op <- parse_int(line, 17, 18)
  if (is.na(op) || op != 3L) return(line)  # only fertilizer ops
  
  fert_id     <- parse_int(line, 20, 23)
  fert_kg     <- parse_num(line, 32, 43)
  frt_surface <- parse_num(line, 45, 50)
  
  if (!is.na(fert_id) && fert_id %in% manure_ids) {
    # manure: inject, keep rate
    if (!is.na(frt_surface)) frt_surface <- 0.00
  } else {
    # commercial: 80% of rate, same placement
    if (!is.na(fert_kg)) fert_kg <- fert_kg * P_mult
  }
  
  if (!is.na(fert_kg)) {
    substr(line, 32, 43) <- sprintf("%12.5f", fert_kg)
  }
  if (!is.na(frt_surface)) {
    substr(line, 45, 50) <- sprintf("%6.2f", frt_surface)
  }
  line
}

edit_mgt_file_nm80 <- function(mgt_path, P_mult, manure_ids) {
  lines <- readLines(mgt_path, warn = FALSE)
  if (!length(lines)) return(invisible(FALSE))
  
  ops_line <- grep("^\\s*Operation\\s+Schedule:", lines)
  if (!length(ops_line)) return(invisible(FALSE))
  ops_line <- ops_line[1]
  
  i <- ops_line + 1L
  while (i <= length(lines) &&
         nzchar(trimws(lines[i])) &&
         !grepl("^\\s*[A-Za-z].*:\\s*$", lines[i])) {
    lines[i] <- update_fert_line_nm80(lines[i],
                                      P_mult    = P_mult,
                                      manure_ids = manure_ids)
    i <- i + 1L
  }
  
  bak <- paste0(mgt_path, ".MultiBMP_NM80.bak")
  file.copy(mgt_path, bak, overwrite = TRUE)
  writeLines(lines, mgt_path, useBytes = TRUE)
  invisible(TRUE)
}

count_nm_edit <- 0L
count_nm_skip <- 0L

for (fp in mgt_files) {
  hru_id <- parse_hru_id_from_mgt(fp)
  if (is.na(hru_id) || !(hru_id %in% bmp_hru_ids)) {
    count_nm_skip <- count_nm_skip + 1L
    next
  }
  edit_mgt_file_nm80(fp, P_mult = P_mult, manure_ids = manure_fert_ids)
  count_nm_edit <- count_nm_edit + 1L
}

cat("\n(2) NM80 + injection applied:",
    "\n  .mgt files edited (Hay/CornFromHay): ", count_nm_edit,
    "\n  .mgt files skipped:                  ", count_nm_skip, "\n")

## ==========================================================================##
##  (3) FOREST BUFFER – FILTERW = 10 m ON NEAR-STREAM HAY HRUs              ##
## ==========================================================================##

update_filterw_line <- function(lines, new_width_m) {
  idx <- grep("\\bFILTERW\\b", lines)
  if (!length(idx)) return(lines)
  
  i   <- idx[1]
  old <- lines[i]
  
  lines[i] <- sub(
    pattern = "^(\\s*)([-0-9.+Ee]+)(\\s*\\|\\s*FILTERW)",
    replacement = sprintf("\\1%.2f    \\3", new_width_m),
    x = old
  )
  lines
}

count_buf_edit <- 0L
count_buf_skip <- 0L

for (fp in mgt_files) {
  hru_id <- parse_hru_id_from_mgt(fp)
  if (is.na(hru_id) || !(hru_id %in% buffer_hrus)) {
    count_buf_skip <- count_buf_skip + 1L
    next
  }
  lines <- readLines(fp, warn = FALSE)
  if (!length(lines)) next
  lines_new <- update_filterw_line(lines, buffer_width_m)
  if (!identical(lines, lines_new)) {
    bak <- paste0(fp, ".MultiBMP_Buffer.bak")
    file.copy(fp, bak, overwrite = TRUE)
    writeLines(lines_new, fp, useBytes = TRUE)
    count_buf_edit <- count_buf_edit + 1L
  }
}

cat("\n(3) Forest buffer applied:",
    "\n  .mgt files edited (near-stream hay HRUs): ", count_buf_edit,
    "\n  .mgt files skipped:                       ", count_buf_skip, "\n")

##############################################################################
# RUN SWAT + EVENT-BASED TP PLOT FOR MULTI-BMP SCENARIO                     #
##############################################################################

pacman::p_load(
  SWATmodel, dplyr, EcoHydRology, base, topmodel, utils,
  lubridate, stringr, diffobj, tidyr, rnoaa, readr, ggplot2
)

run_swat_multi <- function(swat_exe  = "~/new_swat/rev688_64rel_linux",
                           work_dir  = scenario_dir) {
  
  swat_exe <- path.expand(swat_exe)
  work_dir <- path.expand(work_dir)
  
  if (!file.exists(swat_exe)) stop("SWAT executable not found: ", swat_exe)
  if (!dir.exists(work_dir))  stop("Working dir not found: ", work_dir)
  
  setwd(work_dir)
  
  message("Cleaning old output files …")
  old_out <- list.files(pattern = "output\\.")
  if (length(old_out)) file.remove(old_out)
  
  message("Running SWAT in MultiBMP_Rye_NM80_Buffer …")
  system(shQuote(swat_exe), intern = FALSE)
  
  new_out <- list.files(pattern = "output\\.")
  if (length(new_out)) {
    message("SWAT run completed ✔")
    return(new_out)
  } else {
    stop("SWAT produced no output files in scenario_dir.")
  }
}

# ---- run SWAT ----
output_files_multi <- run_swat_multi()
cat("Generated output files in MultiBMP scenario:\n"); print(output_files_multi)

##############################################################################
# EVENT-BASED TP (kg) AT OUTLET (RCH 3)                                      #
##############################################################################

myhomedir <- Sys.getenv("HOME")
basedir   <- myhomedir
codedir   <- file.path(basedir, "swat_LOC", "R")

setwd(scenario_dir)

source(file.path(codedir, "readSWAT_3.R"))
save(readSWAT, file = "readSWAT.R")

load("readSWAT.R")
outdata  <- readSWAT("rch", ".")
rch_data <- subset(outdata, RCH == 3)
rch_data$Date <- rch_data$mdate

Events <- read.csv("Events.csv")
Events$start_date <- as.Date(Events$start_date, "%m/%d/%Y")
Events$end_date   <- as.Date(Events$end_date,   "%m/%d/%Y")

sim_P <- numeric(nrow(Events))
for (i in seq_len(nrow(Events))) {
  ev <- subset(rch_data,
               Date >= Events$start_date[i] &
                 Date <= Events$end_date[i])
  sim_P[i] <- sum(ev$TOT_Pkg, na.rm = TRUE)
}
Events$Total_P_simulated_Multi <- sim_P

ggplot(Events, aes(x = end_date)) +
  geom_line(aes(y = Total_P_simulated_Multi, color = "Simulated (Multi-BMP)"),
            size = 2, alpha = 0.9) +
  geom_line(aes(y = Tot_P, color = "Observed"),
            size = 2, alpha = 0.9) +
  labs(
    x = "Time",
    y = "Total P (kg)",
    color = ""
  ) +
  scale_color_manual(
    values = c("Simulated (Multi-BMP)" = "magenta",
               "Observed"              = "orange")
  ) +
  theme_minimal(base_size = 15) +
  theme(
    plot.title  = element_text(size = 16, hjust = 0.5),
    axis.title  = element_text(size = 15),
    axis.text   = element_text(size = 13),
    panel.border = element_rect(color = "black", fill = NA, size = 1),
    plot.margin  = margin(t = 5, r = 25, b = 5, l = 5, unit = "pt")
  )
