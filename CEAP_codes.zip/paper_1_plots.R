library(dplyr)
library(tidyr)
library(ggplot2)
library(lubridate)

run_dir <- "~/copy_calib/P_calibrated2"

# Get joined SNU–HRU table
obj <- prep_snu_joined(run_dir)
snu_joined <- obj$snu_joined   # now a normal dataframe

# ---- Year-end soil P for each HRU and pool ----
# (You can think of this as your “stock” at the end of each year)
soilP_yearend <- snu_joined %>%
  group_by(HRU, year) %>%
  filter(mdate == max(mdate)) %>%   # last day of that year for that HRU
  slice_tail(n = 1) %>%
  ungroup() %>%
  # long format: one column for pool type, one for value
  select(HRU, year, SOL_LABP = SOL_P, SOL_ORGP = ORG_P) %>%
  pivot_longer(
    cols      = c(SOL_LABP, SOL_ORGP),
    names_to  = "pool",
    values_to = "soilP_kg_ha"
  )

# Optional: nicer labels
soilP_yearend$pool <- factor(
  soilP_yearend$pool,
  levels = c("SOL_LABP", "SOL_ORGP"),
  labels = c("Labile P (SOL_LABP)", "Organic P (SOL_ORGP)")
)

# ---- Figure 4: boxplots by year and pool ----
ggplot(soilP_yearend, aes(x = factor(year), y = soilP_kg_ha)) +
  geom_boxplot(outlier.alpha = 0.3) +
  facet_wrap(~ pool, scales = "free_y", nrow = 1) +
  labs(
    x = "",
    y = "Soil P stock (kg ha⁻¹)",
    title = "Year-end distribution of labile and organic soil P across hay HRUs"
  ) +
  theme_bw(base_size = 14)

ti_map <- read_csv("~/copy_calib/hru/TI_class.csv")

soilP_TI <- snu_joined %>%
  filter(LULC == "ORCD") %>%              # keep if you want only hay HRUs
  arrange(HRU, mdate) %>%
  group_by(HRU) %>%
  summarise(
    labile_start = first(SOL_P),
    labile_end   = last(SOL_P),
    org_start    = first(ORG_P),
    org_end      = last(ORG_P),
    d_labile     = labile_end - labile_start,
    d_org        = org_end   - org_start,
    .groups = "drop"
  ) %>%
  left_join(ti_map, by = "HRU")           # join TI_class in


soilP_TI_long <- soilP_TI %>%
  pivot_longer(
    cols = c(d_labile, d_org),
    names_to  = "pool",
    values_to = "delta_kg_ha"
  ) %>%
  mutate(
    pool = dplyr::recode(
      pool,
      d_labile = "Labile P (SOL_P)",
      d_org    = "Organic P (ORG_P)"
    ),
    TI_class = factor(TI_class)  # order if you have a preferred sequence
  )

ggplot(soilP_TI_long, aes(x = TI_class, y = delta_kg_ha)) +
  geom_hline(yintercept = 0, linetype = "dashed") +
  geom_boxplot(width = 0.7, outlier.alpha = 0.4) +
  facet_wrap(~ pool, scales = "free_y") +
  labs(
    title = "Distribution of soil P pool changes by TI class (2019–2023)",
    x = "TI class",
    y = expression(Delta~"soil P (kg ha"^{-1}*")")
  ) +
  theme_bw(base_size = 14)



# Extract HRU + LULC (unique per HRU)
hru_lulc <- snu_joined %>%
  select(HRU, LULC) %>%
  distinct()

ti_map <- ti_map %>%
  left_join(hru_lulc, by = "HRU")


# Filter hay HRUs and inspect mid-TI classes
hay_midTI <- ti_map %>%
  filter(LULC.x == "ORCD", TI_class >= 3, TI_class <= 6) %>%
  left_join(snu_joined %>% group_by(HRU) %>% summarise(mean_P_loss = mean(P_loss_day_kg_ha)),
            by = "HRU") %>%
  arrange(desc(mean_P_loss))

hay_midTI


#########################################################
#### p hotspot maps, pie chart ##########################
#########################################################

library(readr)
library(dplyr)
library(tidyr)
library(lubridate)

## 1. Read output.hru ---------------------------------------------------------
hru_path <- "~/copy_calib/calibfolderP_baseline"   # <-- put the correct path if needed

hru <- readSWAT("hru", hru_path)

## Make sure date column is proper Date type:
hru <- hru %>%
  mutate(
    mdate = as.Date(mdate),
    LULC  = as.character(LULC)
  )

## 2. Calculate P export -------------------------------------------------------

## 3. Compute P export (using your exact variable names) ----------------------
hru <- hru %>%
  mutate(
    year = year(mdate),
    Pexport = SOLPkg_per_ha +
      P_GWkg_per_ha +
      SEDPkg_per_ha +
      ORGPkg_per_ha
  )

## 4. Filter HRU 69 for year 2023 ---------------------------------------------
hru69_2023 <- hru %>%
  filter(HRU == 39, year == 2023)

## 5. Aggregate P-export components for entire 2023 --------------------------
pexp_components <- hru69_2023 %>%
  summarise(
    SOLP = sum(SOLPkg_per_ha,   na.rm = TRUE),
    P_GW = sum(P_GWkg_per_ha,   na.rm = TRUE),
    SEDP = sum(SEDPkg_per_ha,   na.rm = TRUE),
    ORGP = sum(ORGPkg_per_ha,   na.rm = TRUE)
  ) %>%
  pivot_longer(
    everything(),
    names_to  = "Component",
    values_to = "kgP"
  ) %>%
  mutate(
    Component = factor(Component,
                       levels=c("SOLP","P_GW","SEDP","ORGP"),
                       labels=c("SOLP (Surface runoff)",
                                "P_GW (Groundwater)",
                                "SEDP (Mineral P)",
                                "ORGP (Organic P)")),
    perc = 100 * kgP / sum(kgP)
  )

## 6. Pie chart --------------------------------------------------------------
ggplot(pexp_components, aes(x = "", y = kgP, fill = Component)) +
  geom_col(width = 1) +
  coord_polar(theta = "y") +
  geom_text(aes(label = sprintf("%.1f%%", perc)),
            position = position_stack(vjust = 0.5),
            size = 3) +
  theme_void() +
  labs(title = "HRU 69 – P Export Components (2023)",
       fill = "Component")


hru_annual <- hru %>%
  group_by(HRU, year) %>%
  summarise(Pexport_kg_ha = sum(Pexport, na.rm = TRUE)) %>%
  ungroup()

hru_mean <- hru_annual %>%
  group_by(HRU) %>%
  summarise(mean_Pexport = mean(Pexport_kg_ha, na.rm = TRUE))

library(sf)

hru_shp <- st_read("hru1.shp")

hru_shp <- hru_shp %>%
  rename (HRU = HRU_ID)

map_data <- hru_shp %>%
  left_join(hru_mean, by = "HRU")

library(ggplot2)

p_map <- ggplot(map_data) +
  geom_sf(aes(fill = mean_Pexport), color = NA) +
  scale_fill_gradientn(
    colours = c("#2ECC71", "#F1C40F", "#E74C3C"),
    name = "Mean Annual\nP Export (kg/ha/yr)"
  ) +
  theme_bw() +
  ggtitle("P Hotspot Map (2019–2023 Mean)")


ggsave(
  filename = "P_hotspot_map.pdf",
  plot     = p_map,
  width    = 8,      # inches (adjust if needed)
  height   = 6,      # inches
  units    = "in",
  device   = cairo_pdf   # ensures smooth lines & text
)


################
### P hotspot map by TI ####
################

setwd("~/copy_calib/hru")

# 1. Read TI class for each HRU
ti_df <- read_csv("TI_class.csv", show_col_types = FALSE)

ti_df <- ti_df %>%
  mutate(
    TI_class = as.integer(TI_class),
    TI_cat = case_when(
      TI_class %in% 1:3  ~ "Low (1–3)",
      TI_class %in% 4:6  ~ "Medium (4–6)",
      TI_class %in% 7:10 ~ "High (7–10)",
      TRUE               ~ NA_character_
    ),
    TI_cat = factor(TI_cat,
                    levels = c("Low (1–3)", "Medium (4–6)", "High (7–10)"))
  )

# 2. Join TI info onto P-export summary
hru_mean_ti <- hru_mean %>%
  left_join(ti_df, by = "HRU")

# 3. Join to the HRU polygons (sf)
map_data_ti <- hru_shp %>%
  left_join(hru_mean_ti, by = "HRU")


### Option A – One map faceted by TI category ###

ti_map_facet <- ggplot(map_data_ti) +
  geom_sf(aes(fill = mean_Pexport), color = NA) +
  facet_wrap(~ TI_cat, ncol = 1) +
  scale_fill_viridis_c(
    option = "C",  # or "D", "A", etc.
    name   = "Mean annual\nP export (kg/ha/yr)"
  ) +
  coord_sf() +
  theme_bw() +
  theme(
    strip.background = element_rect(fill = "grey90"),
    strip.text = element_text(face = "bold"),
    legend.position = "right"
  ) +
  labs(
    title = "P Hotspots by TI Category (2019–2023 Mean)",
    x = NULL, y = NULL
  )


ggsave(
  filename = "TI_hotspot_map_facet.pdf",
  plot     = ti_map_facet,
  width    = 12,      # inches (adjust if needed)
  height   = 8,      # inches
  units    = "in",
  device   = cairo_pdf   # ensures smooth lines & text
)

### Option C (simpler) – One map, but TI shown as categories ###

ti_map <- ggplot(map_data_ti) +
  geom_sf(aes(fill = TI_cat), color = NA) +
  scale_fill_brewer(palette = "RdYlGn", direction = -1,
                    name = "TI Category") +
  theme_bw() +
  labs(title = "Topographic Index Categories by HRU",
       x = NULL, y = NULL)


ggsave(
  filename = "TI_hotspot_map.pdf",
  plot     = ti_map,
  width    = 12,      # inches (adjust if needed)
  height   = 8,      # inches
  units    = "in",
  device   = cairo_pdf   # ensures smooth lines & text
)


############################################################

library(dplyr)
library(lubridate)
library(tidyr)

# -------------------------------------------------------
# PATH TO BASELINE RUN
# -------------------------------------------------------
base_dir <- "~/copy_calib/calibfolderP_baseline"


# -------------------------------------------------------
# 1) Year-end Soil Legacy P Table (kg/ha) for hay HRUs
# -------------------------------------------------------
hay_soilP_table <- function(run_dir) {
  
  # Read SWAT outputs
  hru <- readSWAT("hru", run_dir)
  snu <- readSWAT("snu", run_dir)
  
  # Make GIS match
  snu <- snu %>% rename(GIS = GISnum)
  
  # What we need from HRU
  hru_keep <- hru %>% select(mdate, HRU, LULC, AREAkm2, GIS)
  
  # Join and compute soil P
  snu_joined <- snu %>%
    left_join(hru_keep, by = c("mdate", "GIS")) %>%
    mutate(
      mdate      = as.Date(mdate),
      year       = year(mdate),
      soilP_kg_ha = SOL_P + ORG_P
    )
  
  # Filter only hay
  hay_snu <- snu_joined %>% filter(LULC == "ORCD")
  
  # Keep year-end values
  hay_year_end <- hay_snu %>%
    group_by(HRU, year) %>%
    filter(mdate == max(mdate)) %>%
    slice_tail(n = 1) %>%
    ungroup() %>%
    select(HRU, year, soilP_kg_ha)
  
  # Pivot
  hay_legacy_table <- hay_year_end %>%
    pivot_wider(
      names_from  = year,
      values_from = soilP_kg_ha
    ) %>%
    arrange(HRU)
  
  hay_legacy_table
}

# BASELINE soil P table
hay_legacy_baseline <- hay_soilP_table(base_dir)
#hay_legacy_baseline

hay_P_loss_annual <- function(run_dir) {
  
  hru <- readSWAT("hru", run_dir)
  
  hru %>%
    filter(LULC == "ORCD") %>%         # only hay HRUs
    mutate(
      mdate = as.Date(mdate),
      year  = year(mdate),
      P_loss_day_kg_ha =
        coalesce(SOLPkg_per_ha, 0) +
        coalesce(SEDPkg_per_ha, 0) +
        coalesce(P_GWkg_per_ha, 0)
    ) %>%
    group_by(HRU, year) %>%
    summarise(
      P_loss_kg_ha_yr = sum(P_loss_day_kg_ha, na.rm = TRUE),
      .groups = "drop"
    )
}

hay_loss_baseline <- hay_P_loss_annual(base_dir)
#hay_loss_baseline

loss_rank <- hay_loss_baseline %>%
  group_by(HRU) %>%
  summarise(
    mean_loss = mean(P_loss_kg_ha_yr, na.rm = TRUE)
  ) %>%
  arrange(desc(mean_loss))


loss_rank <- loss_rank %>%
  mutate(
    cum_loss = cumsum(mean_loss),
    total_loss = sum(mean_loss),
    cum_pct = cum_loss / total_loss * 100,
    HRU_rank = row_number()
  )


library(ggplot2)

ggplot(loss_rank, aes(x = HRU_rank, y = cum_pct)) +
  geom_line(color = "purple", size = 1.3) +
  geom_point(color = "purple", size = 2) +
  scale_x_continuous(breaks = seq(0, 53, by = 5))+
  labs(
    title = "Lorenz Curve of Hay HRU P Export",
    x = "HRUs (sorted by descending P export)",
    y = "Cumulative contribution to total P export (%)"
  ) +
  theme_bw(base_size = 14)


##########################################################################
########### Tables ##################

library(dplyr)
library(readr)
library(lubridate)

base_dir <- "~/copy_calib/calibfolderP_baseline"

#-----------------------------
# 1. Get annual P loss for hay HRUs (baseline)
#-----------------------------
hay_loss_baseline <- hay_P_loss_annual(base_dir)
# columns: HRU, year, P_loss_kg_ha_yr

#-----------------------------
# 2. Mean export per HRU (kg/ha/yr)
#-----------------------------
export_by_HRU <- hay_loss_baseline %>%
  group_by(HRU) %>%
  summarise(
    P_export_kg_ha_yr = mean(P_loss_kg_ha_yr, na.rm = TRUE),
    .groups = "drop"
  )

#-----------------------------
# 3. HRU area (ha) for hay HRUs
#-----------------------------
hru_base <- readSWAT("hru", base_dir)

hay_hru_info <- hru_base %>%
  filter(LULC == "ORCD") %>%              # only hay HRUs
  select(HRU, AREAkm2) %>%
  distinct(HRU, .keep_all = TRUE) %>%
  mutate(area_ha = AREAkm2 * 100)

#-----------------------------
# 4. Join TI class from ti_map
#   (ti_map must have columns HRU, TI_class)
#-----------------------------

# 1. Read TI class for each HRU
ti_map <- read_csv("TI_class.csv", show_col_types = FALSE)

export_hay <- export_by_HRU %>%
  left_join(hay_hru_info, by = "HRU") %>%
  left_join(ti_map %>% select(HRU, TI_class), by = "HRU")

#----------------------------------------------------
# A. Table of HRUs sorted by P export (top 10–20 rows)
#----------------------------------------------------
table_A <- export_hay %>%
  arrange(desc(P_export_kg_ha_yr)) %>%
  select(HRU, TI_class, P_export_kg_ha_yr) %>%
  slice_head(n = 20)        # change to 10 if you want top 10 only

table_A
# You can write it out if you like:
write_csv(table_A, "HRU_rank_table.csv")

#----------------------------------------------------
# B. Summary statistics table
#----------------------------------------------------

# total load per HRU (kg/yr) using mean export and area
export_area <- export_hay %>%
  mutate(
    load_kg_yr = P_export_kg_ha_yr * area_ha
  )

total_load  <- sum(export_area$load_kg_yr, na.rm = TRUE)
total_area  <- sum(export_area$area_ha,    na.rm = TRUE)

# Area fraction contributing the first 50% of total P export
area_for_50pct <- export_area %>%
  arrange(desc(load_kg_yr)) %>%
  mutate(
    cum_load = cumsum(load_kg_yr),
    cum_area = cumsum(area_ha)
  ) %>%
  filter(cum_load <= 0.5 * total_load) %>%
  summarise(area_ha_50 = max(cum_area, na.rm = TRUE)) %>%
  pull(area_ha_50)

frac_area_50pct <- 100 * area_for_50pct / total_area

# % of HRUs exporting > 4 kg/ha/yr
frac_HRU_gt4 <- export_area %>%
  summarise(frac = mean(P_export_kg_ha_yr > 4, na.rm = TRUE) * 100) %>%
  pull(frac)

# Basic export stats (kg/ha/yr)
mean_export   <- mean(export_area$P_export_kg_ha_yr, na.rm = TRUE)
median_export <- median(export_area$P_export_kg_ha_yr, na.rm = TRUE)
p90_export    <- quantile(export_area$P_export_kg_ha_yr, 0.9, na.rm = TRUE)
max_export    <- max(export_area$P_export_kg_ha_yr, na.rm = TRUE)

summary_B <- tibble::tibble(
  Metric = c(
    "Watershed mean P export (kg/ha/yr)",
    "Median export (kg/ha/yr)",
    "90th percentile export (kg/ha/yr)",
    "Max export (kg/ha/yr)",
    "% of hay area contributing 50% of total P load",
    "% of hay HRUs exporting > 4 kg/ha/yr"
  ),
  Value = c(
    mean_export,
    median_export,
    p90_export,
    max_export,
    frac_area_50pct,
    frac_HRU_gt4
  )
)

summary_B
write_csv(summary_B, "P_export_summary_table.csv")


###################################
###################################################

library(dplyr)
library(ggplot2)

# Read event table
Events <- read.csv("Events.csv")

# Convert dates (useful later even if not strictly needed for this plot)
Events$start_date <- as.Date(Events$start_date, format = "%m/%d/%Y")
Events$end_date   <- as.Date(Events$end_date,   format = "%m/%d/%Y")

# If vol is still in liters, convert to m³.
# If you've already multiplied by 0.001 before saving Events.csv, comment out this line.
Events$vol_m3 <- Events$vol * 0.001   # observed event runoff volume (m³)

# Rename for clarity
Events$Q_event_m3  <- Events$vol_m3         # observed event volume
Events$Tot_P_obskg <- Events$Tot_P          # observed TP load (kg) – change name if needed


### plot ###

events_plot <- Events %>%
  filter(!is.na(Tot_P_obskg),
         !is.na(Q_event_m3),
         Q_event_m3 > 0)

ggplot(events_plot,
       aes(x = Q_event_m3 / 1e3,    # 10^3 m³ to keep axis numbers moderate
           y = Tot_P_obskg)) +
  geom_point(size = 2) +
  geom_smooth(method = "lm", se = FALSE, linetype = "dashed") +
  labs(
    x = expression("Event runoff volume  ("*10^3*" m"^3*")"),
    y = "Observed event TP load (kg)",
    title = "Observed event-scale TP load vs runoff volume"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5)
  )


### log-plot ###

ggplot(events_plot,
       aes(x = Q_event_m3,
           y = Tot_P_obskg)) +
  geom_point(size = 2) +
  geom_smooth(method = "lm", se = FALSE, linetype = "dashed") +
  scale_x_log10() +
  scale_y_log10() +
  labs(
    x = "Event runoff volume (m³, log scale)",
    y = "Observed event TP load (kg, log scale)",
    title = "Log–log relationship between event runoff and TP export"
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title = element_text(hjust = 0.5)
  )
