suppressPackageStartupMessages({
  library(fs)
  library(dplyr)
  library(purrr)
  library(lubridate)
  library(tidyr)
  library(stringr)
  library(furrr)
})

# 1) Root folder where all MC runs live
#    (Baseline, Covercrop_WinterRye, ForestBuffer10m, etc.)
#run_root <- "/scratch/sabrinam21_MC1/MC_40yr_runs_safe"

scratch_root <- file.path("/scratch", Sys.getenv("USER"), "MC3")
run_root <- file.path(scratch_root, "MC_40yr_runs_safe")

if (!dir_exists(run_root)) {
  stop("run_root not found: ", run_root)
}

# 2) readSWAT function
source("~/swat_LOC/R/readSWAT_3.R")

# ---- Helper: TP long-term mean (years 11–40) ---------------------

summarise_TP_longterm <- function(run_dir,
                                  outlet_rch   = 3,
                                  warmup_years = 10) {
  rch <- readSWAT("rch", run_dir) %>%
    filter(RCH == outlet_rch) %>%
    mutate(year = lubridate::year(mdate))
  
  years <- sort(unique(rch$year))
  if (length(years) <= warmup_years) {
    warning("Fewer years than warmup_years in run_dir = ", run_dir)
    return(tibble(mean_TP_load_kg = NA_real_))
  }
  
  analysis_years <- years[(warmup_years + 1):length(years)]
  
  annual <- rch %>%
    filter(year %in% analysis_years) %>%
    group_by(year) %>%
    summarise(
      TP_load_kg = sum(TOT_Pkg, na.rm = TRUE),
      .groups = "drop"
    )
  
  annual %>%
    summarise(mean_TP_load_kg = mean(TP_load_kg, na.rm = TRUE))
}

###############

# ---- List all scenario folders under run_root --------------------

scen_dirs  <- fs::dir_ls(run_root, type = "directory", recurse = FALSE)
scen_names <- basename(scen_dirs)

scen_dirs
scen_names

# ---- Build table of all completed MC runs ------------------------

mc_runs <- purrr::map2_dfr(
  scen_dirs, scen_names,
  ~ {
    scen_dir  <- .x
    scen_name <- .y
    
    mc_dirs <- fs::dir_ls(
      scen_dir,
      type   = "directory",
      regexp = "mc_\\d+$",   # mc_001, mc_040, etc.
      recurse = FALSE
    )
    
    # keep only those with output.rch present
    has_rch <- fs::file_exists(file.path(mc_dirs, "output.rch"))
    mc_dirs <- mc_dirs[has_rch]
    
    if (!length(mc_dirs)) {
      message("No completed MC runs found for scenario: ", scen_name)
      return(tibble::tibble())
    }
    
    tibble::tibble(
      scen_name = scen_name,
      mc_dir    = mc_dirs,
      mc_id     = as.integer(sub("mc_", "", basename(mc_dirs)))
    )
  }
)

mc_runs
nrow(mc_runs)           # should be around 280
table(mc_runs$scen_name)

# ---- Tiny test: 2 runs per scenario -----------------------------

summarise_TP_one_run <- function(scen_name, mc_dir, mc_id) {
  message("TP-only summarising ", scen_name, " | ", basename(mc_dir))
  
  TP_stats <- tryCatch(
    summarise_TP_longterm(mc_dir),
    error = function(e) {
      warning("summarise_TP_longterm failed in ", mc_dir, ": ", e$message)
      tibble::tibble(mean_TP_load_kg = NA_real_)
    }
  )
  
  tibble::tibble(
    scen_name       = scen_name,
    mc_id           = mc_id,
    mean_TP_load_kg = TP_stats$mean_TP_load_kg
  )
}

set.seed(123)
test_runs <- mc_runs %>%
  dplyr::group_by(scen_name) %>%
  dplyr::slice_head(n = 2) %>%
  dplyr::ungroup()

system.time({
  TP_test_df <- purrr::pmap_dfr(
    list(test_runs$scen_name, test_runs$mc_dir, test_runs$mc_id),
    summarise_TP_one_run
  )
})

TP_test_df

library(furrr)

# use a moderate number of workers so the filesystem is not overloaded
# plan(multicore, workers = 8)   
# 
# TP_MC_df <- future_pmap_dfr(
#   list(mc_runs$scen_name, mc_runs$mc_dir, mc_runs$mc_id),
#   summarise_TP_one_run,
#   .progress = TRUE
# )

library(future)
library(furrr)

plan(multisession, workers = 8)
library(progressr)
handlers("txtprogressbar")

with_progress({
  TP_MC_df <- future_pmap_dfr(
    list(mc_runs$scen_name, mc_runs$mc_dir, mc_runs$mc_id),
    summarise_TP_one_run,
    .progress = TRUE
  )
})


# checks
nrow(TP_MC_df)
table(TP_MC_df$scen_name)

saveRDS(TP_MC_df, file = file.path(run_root, "TP_MC_df_40yr.rds"))

library(dplyr)

# ---- Baseline ensemble ------------------------------------------

baseline_TP <- TP_MC_df %>%
  filter(scen_name == "Baseline") %>%
  select(
    mc_id,
    baseline_TP_load_kg = mean_TP_load_kg
  )

# ---- Join each BMP run with its matching baseline run -----------

TP_MC_joined <- TP_MC_df %>%
  filter(scen_name != "Baseline") %>%
  left_join(baseline_TP, by = "mc_id") %>%
  mutate(
    TP_red_pct = 100 * (baseline_TP_load_kg - mean_TP_load_kg) /
      baseline_TP_load_kg
  )

# quick sanity check
summary(TP_MC_joined$TP_red_pct)

# ---- Risk metrics per scenario ----------------------------------

risk_TP <- TP_MC_joined %>%
  group_by(scen_name) %>%
  summarise(
    n_runs            = sum(!is.na(TP_red_pct)),
    median_TP_red_pct = median(TP_red_pct, na.rm = TRUE),
    prob_TP_red_30    = mean(TP_red_pct >= 30, na.rm = TRUE),
    .groups = "drop"
  )

risk_TP

library(ggplot2)

ggplot(TP_MC_joined, aes(x = scen_name, y = TP_red_pct)) +
  geom_hline(yintercept = 30, linetype = "dashed", color = "red", size = 1) +
  geom_boxplot(fill = "skyblue", alpha = 0.6) +
  labs(
    x = "BMP Scenario",
    y = "TP reduction relative to Baseline (%)",
    title = "Monte Carlo distribution of long-term TP reduction (years 11–40)",
    subtitle = "Dashed line = 30% reduction target"
  ) +
  theme_bw(base_size = 13) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1)
  )

ggplot(risk_TP, aes(x = scen_name, y = prob_TP_red_30)) +
  geom_col(fill = "steelblue") +
  labs(
    x = "BMP Scenario",
    y = "Probability of achieving ≥30% TP reduction",
    title = ""
  ) +
  scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
  theme_bw(base_size = 13) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


# Save raw Monte Carlo TP loads (40 runs × 7 scenarios)
write.csv(TP_MC_df,
          file = "~/MC_TP_raw_40runs_feb26.csv",
          row.names = FALSE)

# Save reductions relative to baseline (per run)
write.csv(TP_MC_joined,
          file = "~/MC_TP_reductions_40runs.csv",
          row.names = FALSE)

# Save risk summary table (per scenario)
write.csv(risk_TP,
          file = "~/MC_TP_risk_summary.csv",
          row.names = FALSE)


library(ggplot2)
library(dplyr)

# Ensure scen_name is ordered properly
TP_MC_df$scen_name <- factor(TP_MC_df$scen_name,
                             levels = c("Covercrop_WinterRye",
                                        "ForestBuffer10m",
                                        "MultiBMP_Rye_NM80_Buffer",
                                        "NM80_injection",
                                        "cropremoval_PMining",
                                        "NoTill"),
                             labels = c("Cover Crop",
                                        "Forest Buffer",
                                        "Multi-BMP Suite",
                                        "Nutrient Mgmt (NM80)",
                                        "Crop Removal/P-mining",
                                        "No-Till"))

# 1. Extract baseline values (renamed cleanly)
baseline_vals <- TP_MC_df %>%
  filter(scen_name == "Baseline") %>%
  select(mc_id, baseline_TP = mean_TP_load_kg)

# 2. Join and compute TP reduction
TP_for_plot <- TP_MC_df %>%
  filter(scen_name != "Baseline") %>%
  left_join(baseline_vals, by = "mc_id") %>%
  mutate(
    TP_red_pct = 100 * (baseline_TP - mean_TP_load_kg) / baseline_TP
  )


# Violin + jitter plot
ggplot(TP_for_plot, aes(x = scen_name, y = TP_red_pct, fill = scen_name)) +
  geom_violin(trim = FALSE, alpha = 0.8)+
geom_boxplot(width = 0.1, outlier.size = 1.5)+

  geom_hline(yintercept = 30, linetype = "dashed", color = "red", size = 1) +
  labs(
    title = "Monte Carlo distribution of long-term TP reductions (years 11–40)",
    y = "TP Reduction (%)",
    x = NULL
  ) +
  theme_minimal(base_size = 15) +
  theme(
    axis.text.x = element_text(angle = 35, hjust = 1),
    legend.position = "none",
    plot.title = element_text(face = "bold", size = 16)
  )
