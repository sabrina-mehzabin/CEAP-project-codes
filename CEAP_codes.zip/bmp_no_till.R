##############################################################################
# BMP: NoTill
# - Start from P-calibrated baseline
# - Copy to BMP_scenarios/NoTill
# - On HRUs in Hay/CornFromHay 70/30 split:
#     * All tillage ops (MGT_OP = 6) → TILL_ID = 4  (no-till)
#     * For CornFromHay HRUs only: header USLE_P = 0.4
#     * Hay HRUs: USLE_P left as-is (baseline)
##############################################################################

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(stringr)
})

## ---------- USER INPUT -----------------------------------------------------

# # 1) P-calibrated baseline (already has your final .mgt schedules)
# baselineP_dir  <- "~/copy_calib/calibfolderP_baseline"
# 
# # 2) Folder where BMP scenarios live
# bmp_root       <- "~/copy_calib/BMP_scenarios_final"
# 
# # 3) Scenario name for this BMP
# scenario_name  <- "NoTill"
# scenario_dir   <- file.path(bmp_root, scenario_name)

# 1) Use the NEW 40-yr baseline with weather generator
baselineP_dir  <- "~/copy_calib/calibfolderP_baseline_40yrWGN_new"

# 2) (Recommended) keep 40-yr BMPs separate from old 8-yr BMPs
bmp_root       <- "~/copy_calib/BMP_scenarios_40yr_new"

scenario_name  <- "NoTill"
scenario_dir   <- file.path(bmp_root, scenario_name)


# 4) Soil-P initialization folder (same as in your soil P init script)
#    This MUST already contain hay_corn_split.csv from that script.
sol_dir        <- "~/copy_calib/P_calibrated2"
hay_split_csv  <- file.path(sol_dir, "hay_corn_split.csv")

# 5) No-till settings
no_till_id     <- 4L          # TILL_ID for zero-till
usle_p_corn    <- 0.4         # USLE_P only for CornFromHay HRUs

## ---------- PREP & COPY BASELINE -------------------------------------------

baselineP_dir <- path.expand(baselineP_dir)
scenario_dir  <- path.expand(scenario_dir)
sol_dir       <- path.expand(sol_dir)

if (!dir.exists(baselineP_dir)) {
  stop("baselineP_dir not found: ", baselineP_dir)
}

dir.create(scenario_dir, recursive = TRUE, showWarnings = FALSE)

# Copy CONTENTS of baseline directory into scenario_dir
baseline_files <- list.files(baselineP_dir, full.names = TRUE, recursive = TRUE)

for (src in baseline_files) {
  # path relative to baselineP_dir
  rel  <- sub(paste0("^", baselineP_dir, "/"), "", src)
  dest <- file.path(scenario_dir, rel)
  dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
  file.copy(src, dest, overwrite = TRUE)
}

cat("Baseline copied into scenario directory:\n  ", scenario_dir, "\n")

## ---------- LOAD EXISTING 70/30 HAY SPLIT ----------------------------------
# We are REUSING the same hay_corn_split.csv created by soil P init,
# so we target exactly the same HRUs (no new random split).

if (!file.exists(hay_split_csv)) {
  stop("hay_corn_split.csv not found at: ", hay_split_csv,
       "\nRun the soil P initialization script first so this file exists.")
}

hay_split <- read_csv(hay_split_csv, show_col_types = FALSE) %>%
  dplyr::mutate(
    HRU_ID = as.integer(HRU_ID),
    group  = trimws(group)
  )

hay_split <- read_csv(hay_split_csv, show_col_types = FALSE)

hay_split$HRU_ID <- as.integer(hay_split$HRU_ID)
hay_split$group  <- trimws(hay_split$group)


bmp_hru_ids <- hay_split %>%
  dplyr::filter(group %in% c("Hay", "CornFromHay")) %>%
  dplyr::pull(HRU_ID)

bmp_hru_ids <- base::unique(bmp_hru_ids)

bmp_hru_ids

# Named vector: HRU_ID -> group (Hay / CornFromHay)
hru_group <- setNames(hay_split$group, hay_split$HRU_ID)

cat("Number of HRUs in Hay/CornFromHay split: ", length(bmp_hru_ids), "\n")

## ---------- HELPERS TO PARSE / EDIT .MGT FILES -----------------------------

# Parse HRU_ID from .mgt header line: "HRU:   23  Subbasin: ..."
parse_hru_id_from_mgt <- function(fp) {
  first_line <- readr::read_lines(fp, n_max = 1)
  hru_token  <- stringr::str_extract(first_line, "HRU:\\s*\\d+")
  if (is.na(hru_token)) return(NA_integer_)
  as.integer(stringr::str_extract(hru_token, "\\d+"))
}

parse_int <- function(line, start, end) {
  as.integer(trimws(substr(line, start, end)))
}

# ---------- (A) Update tillage lines: TILL_ID -> 4 for MGT_OP = 6 ----------
update_tillage_line_notill <- function(line, new_till_id = no_till_id) {
  op <- parse_int(line, 17, 18)
  if (is.na(op) || op != 6L) return(line)  # only tillage operations
  
  # TILL_ID is at columns 20–23 in your format
  substr(line, 20, 23) <- sprintf("%4d", as.integer(new_till_id))
  line
}

# ---------- (B) Header updater for USLE_P -----------------------------------
# This is adapted from your base mgt_update_header_by_label, but limited
# to a single key ("USLE_P") and used only above "Operation Schedule:".

update_usle_p_header <- function(lines, new_val) {
  if (is.null(new_val) || is.na(new_val)) return(lines)
  
  # Only look above the "Operation Schedule:" block
  ops_line <- grep("^\\s*Operation\\s+Schedule:", lines)
  end_ix   <- if (length(ops_line)) ops_line[1] - 1 else length(lines)
  
  if (end_ix < 1) end_ix <- length(lines)
  
  # Find the line containing "| USLE_P"
  ix <- grep("\\|\\s*USLE_P\\b", lines[seq_len(end_ix)], perl = TRUE)
  if (!length(ix)) return(lines)  # silently skip if not found
  
  tgt <- ix[1]
  
  # Replace the number immediately before "| USLE_P"
  lines[tgt] <- sub(
    pattern = "([-+]?\\d*\\.?\\d+)(?=\\s*\\|\\s*USLE_P\\b)",
    replacement = as.character(new_val),
    x = lines[tgt],
    perl = TRUE
  )
  
  lines
}

# ---------- Edit a single .mgt file ----------------------------------------
edit_mgt_file_notill <- function(mgt_path, hru_group_label,
                                 usle_p_corn = usle_p_corn,
                                 new_till_id = no_till_id) {
  lines <- readLines(mgt_path, warn = FALSE)
  if (!length(lines)) return(invisible(FALSE))
  
  # 1) If CornFromHay: update header USLE_P to 0.4
  if (!is.na(hru_group_label) && hru_group_label == "CornFromHay") {
    lines <- update_usle_p_header(lines, new_val = usle_p_corn)
  }
  # For Hay HRUs, we do not touch USLE_P (baseline value stays).
  
  # 2) Edit operation schedule block (tillage → no-till)
  ops_line <- grep("^\\s*Operation\\s+Schedule:", lines)
  if (!length(ops_line)) {
    # no schedule found, just write back header changes if any
    bak <- paste0(mgt_path, ".NoTill.bak")
    file.copy(mgt_path, bak, overwrite = TRUE)
    writeLines(lines, mgt_path, useBytes = TRUE)
    return(invisible(TRUE))
  }
  ops_line <- ops_line[1]
  
  i <- ops_line + 1L
  while (i <= length(lines) &&
         nzchar(trimws(lines[i])) &&
         !grepl("^\\s*[A-Za-z].*:\\s*$", lines[i])) {
    
    lines[i] <- update_tillage_line_notill(lines[i], new_till_id = new_till_id)
    i <- i + 1L
  }
  
  # 3) Backup and write
  bak <- paste0(mgt_path, ".NoTill.bak")
  file.copy(mgt_path, bak, overwrite = TRUE)
  writeLines(lines, mgt_path, useBytes = TRUE)
  
  invisible(TRUE)
}

## ---------- APPLY BMP ONLY TO HAY / CORN-FROM-HAY HRUs ---------------------

mgt_files <- list.files(scenario_dir,
                        pattern = "^[^.].*\\.mgt$",
                        full.names = TRUE,
                        recursive = TRUE)

count_edit <- 0L
count_skip <- 0L

for (fp in mgt_files) {
  hru_id <- parse_hru_id_from_mgt(fp)
  
  # Skip if HRU_ID not found or not in the Hay/CornFromHay pool
  if (is.na(hru_id) || !(hru_id %in% bmp_hru_ids)) {
    count_skip <- count_skip + 1L
    next
  }
  
  # Get group for this HRU (Hay or CornFromHay)
  grp <- hru_group[as.character(hru_id)]
  if (is.na(grp)) grp <- NA_character_
  
  edit_mgt_file_notill(fp,
                       hru_group_label = grp,
                       usle_p_corn     = usle_p_corn,
                       new_till_id     = no_till_id)
  count_edit <- count_edit + 1L
}

cat("\nBMP NoTill summary:",
    "\n  .mgt files edited (Hay/CornFromHay HRUs): ", count_edit,
    "\n  .mgt files skipped:                       ", count_skip,
    "\n  Scenario directory:                       ", scenario_dir, "\n\n")

## ---------- RUN SWAT IN SCENARIO FOLDER ------------------------------------

pacman::p_load(SWATmodel,dplyr,EcoHydRology,base,topmodel,utils, lubridate,stringr,diffobj,tidyr,rnoaa,readr,ggplot2)
run_swat <- function(swat_exe  = "~/new_swat/rev688_64rel_linux",
                     work_dir  = scenario_dir) {
  
  swat_exe <- path.expand(swat_exe)
  work_dir <- path.expand(work_dir)
  
  if (!file.exists(swat_exe)) stop("SWAT executable not found: ", swat_exe)
  if (!dir.exists(work_dir))  stop("Working dir not found: ", work_dir)
  
  setwd(work_dir)
  
  message("Cleaning old output files …")
  old_out <- list.files(pattern = "output\\.")
  if (length(old_out)) file.remove(old_out)
  
  message("Running SWAT in NoTill …")
  system(shQuote(swat_exe), intern = FALSE)
  
  new_out <- list.files(pattern = "output\\.")
  if (length(new_out)) {
    message("SWAT run completed ✔")
    return(new_out)
  } else {
    stop("SWAT produced no output files in scenario_dir.")
  }
}

# ── run it ───────────────────────────────────────────────────────────────────
output_files <- run_swat()
cat("Generated output files in NoTill:\n"); print(output_files)

##############################################################################
# Post-processing: same as your NM80 script (event-based P comparison)
##############################################################################

myhomedir = Sys.getenv("HOME")
basedir   = myhomedir
codedir   = paste0(basedir,"/swat_LOC/R" )
source(paste0(codedir, "/readSWAT_3.R"))
save(readSWAT,file="readSWAT.R")

# # Read HRU output if needed
# out_Calib_Tflo_hru <- readSWAT("hru")
# output_hru_1       <- out_Calib_Tflo_hru[out_Calib_Tflo_hru$SUB==1,]

# Read output.rch and keep reach 3
outdata  <- readSWAT("rch", ".")
rch_data <- subset(outdata, RCH == 3)
rch_data$Date <- rch_data$mdate

# Read event definitions + observed loads
Events <- read.csv("Events.csv")
Events$start_date <- as.Date(Events$start_date, "%m/%d/%Y")
Events$end_date   <- as.Date(Events$end_date,   "%m/%d/%Y")

# Aggregate simulated TP per event (kg)
sim_P <- numeric(nrow(Events))
for (i in seq_len(nrow(Events))) {
  ev <- subset(rch_data,
               Date >= Events$start_date[i] &
                 Date <= Events$end_date[i])
  sim_P[i] <- sum(ev$TOT_Pkg, na.rm = TRUE)
}
Events$Total_P_simulated <- sim_P

# Simple comparison plot (same style as before)
library(ggplot2)

ggplot(Events, aes(x = end_date)) +
  geom_line(aes(y = Total_P_simulated, color = "Simulated"), size = 2, alpha = 0.9) +
  geom_line(aes(y = Tot_P,            color = "Observed"),  size = 2, alpha = 0.9) +
  labs(
    x = "Time",
    y = "Total P (kg)",
    color = ""
  ) +
  scale_color_manual(
    values = c("Simulated" = "magenta", "Observed" = "orange")
  ) +
  theme_minimal(base_size = 15) +
  theme(
    plot.title  = element_text(size = 16, hjust = 0.5),
    axis.title  = element_text(size = 15),
    axis.text   = element_text(size = 13),
    panel.border = element_rect(color = "black", fill = NA, size = 1),
    plot.margin = margin(t = 5, r = 25, b = 5, l = 5, unit = "pt")
  )

