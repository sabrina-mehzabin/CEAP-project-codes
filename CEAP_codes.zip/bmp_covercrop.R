##############################################################################
# BMP: S2_WinterRye (Winter Rye Cover Crop)
#
# - Start from P-calibrated baseline: calibfolderP_baseline
# - Copy to BMP_scenarios/S2_WinterRye
# - Use existing soilP_init_mapping_for_mgt.csv for Hay / CornFromHay grouping
# - For HRUs with group == "CornFromHay":
#       * Replace their operation schedule with:
#           - same corn rotation as baseline
#           - + winter rye kill in early spring
#           - + winter rye planting after corn / fall manure / tillage
# - For HRUs with group == "Hay":
#       * Rebuild the same hay rotation as baseline (no cover crop change)
# - For other HRUs (NonHay etc.): do nothing
##############################################################################

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(stringr)
})

## ---------- USER INPUT -----------------------------------------------------

# # 1) P-calibrated baseline directory
# baselineP_dir <- "~/copy_calib/calibfolderP_baseline"
# 
# # 2) BMP scenario root and name
# bmp_root      <- "~/copy_calib/BMP_scenarios_final"
# scenario_name <- "Covercrop_WinterRye"
# scenario_dir  <- file.path(bmp_root, scenario_name)

# 1) Use the NEW 40-yr baseline with weather generator
baselineP_dir  <- "~/copy_calib/calibfolderP_baseline_40yrWGN"

# 2) (Recommended) keep 40-yr BMPs separate from old 8-yr BMPs
bmp_root       <- "~/copy_calib/BMP_scenarios_40yr"

scenario_name  <- "Covercrop_WinterRye"
scenario_dir   <- file.path(bmp_root, scenario_name)


# 3) Soil-P mapping file (contains HRU_ID, LUSE, group, init_ppm)
mapping_csv   <- file.path(baselineP_dir, "soilP_init_mapping_for_mgt.csv")

# 4) Winter rye parameters
RYE_PLANT_ID  <- 5       # from your crop.dat
RYE_HEAT_UNITS <- 1000.0 # choose a reasonable value; adjust if needed

# 5) Rotation recipes per cohort (same as your baseline Script B)
rotation_for_hay_cohort  <- c(hay = 4, corn = 2, hay = 2)
rotation_for_corn_cohort <- c(corn = 6, hay = 2)

TOTAL_COLS <- 100        # total fixed width of op lines

## ---------- PREP & COPY BASELINE -------------------------------------------

baselineP_dir <- path.expand(baselineP_dir)
scenario_dir  <- path.expand(scenario_dir)

if (!dir.exists(baselineP_dir)) {
  stop("baselineP_dir not found: ", baselineP_dir)
}

dir.create(scenario_dir, recursive = TRUE, showWarnings = FALSE)

# Copy contents of baseline into scenario_dir only once
baseline_files <- list.files(baselineP_dir, full.names = TRUE, recursive = TRUE)

for (src in baseline_files) {
  rel  <- sub(paste0("^", baselineP_dir, "/"), "", src)  # relative path
  dest <- file.path(scenario_dir, rel)
  dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
  file.copy(src, dest, overwrite = TRUE)
}

cat("Baseline copied into scenario directory:\n  ", scenario_dir, "\n")

## ---------- LOAD EXISTING HAY / CORN SPLIT ---------------------------------

if (!file.exists(mapping_csv)) {
  stop("soilP_init_mapping_for_mgt.csv not found at: ", mapping_csv)
}

mapping <- read_csv(mapping_csv, show_col_types = FALSE) %>%
  mutate(
    HRU_ID = as.integer(HRU_ID),
    group  = trimws(group)
  )

hay_hrus   <- mapping %>% filter(group == "Hay")         %>% pull(HRU_ID) %>% unique()
corn_hrus  <- mapping %>% filter(group == "CornFromHay") %>% pull(HRU_ID) %>% unique()

cat("HRUs by group from soilP_init_mapping_for_mgt.csv:",
    "\n  Hay HRUs:         ", length(hay_hrus),
    "\n  CornFromHay HRUs: ", length(corn_hrus), "\n")

## ---------- FIXED-WIDTH HELPERS --------------------------------------------

fixed_line <- function(specs, total_cols = TOTAL_COLS) {
  buf <- strrep(" ", total_cols)
  for (i in seq_len(nrow(specs))) {
    s <- sprintf(specs$fmt[i], specs$val[i])
    w <- specs$width[i]
    if (nchar(s) < w) s <- sprintf(paste0("%", w, "s"), s)
    if (nchar(s) > w) s <- substr(s, 1, w)
    substr(buf, specs$col[i], specs$col[i] + w - 1) <- s
  }
  buf
}

# MONTH 2–3 (i2), DAY 5–6 (i2), HUSC 8–15 (f8.3), MGT_OP 17–18 (i2)
common_prefix_specs <- function(month, day, mgt_op, husc = 0) {
  data.frame(
    name  = c("MONTH","DAY","HUSC","MGT_OP"),
    col   = c(2,       5,     8,     17),
    width = c(2,       2,     8,      2),
    fmt   = c("%02d","%02d","%8.3f","%2d"),
    val   = c(month,   day,   husc,   mgt_op),
    stringsAsFactors = FALSE
  )
}

build_tillage <- function(month, day, TILL_ID, husc = 0) {
  spec <- common_prefix_specs(month, day, 6, husc)
  spec2 <- rbind(spec, data.frame(name="TILL_ID", col=20, width=4, fmt="%4d", val=TILL_ID))
  fixed_line(spec2)
}

build_fertilizer <- function(month, day, FERT_ID, FERT_KG, FRT_SURFACE, husc = 0) {
  if (is.character(FERT_KG)) FERT_KG <- as.numeric(gsub(",", "", FERT_KG))
  spec <- common_prefix_specs(month, day, 3, husc)
  spec2 <- rbind(
    spec,
    data.frame(name="FERT_ID",     col=20, width=4,  fmt="%4d",     val=FERT_ID),
    data.frame(name="FERT_KG",     col=32, width=12, fmt="%12.5f",  val=FERT_KG),
    data.frame(name="FRT_SURFACE", col=45, width=6,  fmt="%6.2f",   val=FRT_SURFACE)
  )
  fixed_line(spec2)
}

build_planting <- function(month, day, PLANT_ID, HEAT_UNITS, husc = 0) {
  spec <- common_prefix_specs(month, day, 1, husc)
  spec2 <- rbind(
    spec,
    data.frame(name="PLANT_ID",   col=20, width=4,  fmt="%4d",     val=PLANT_ID),
    data.frame(name="HEAT_UNITS", col=32, width=12, fmt="%12.5f",  val=HEAT_UNITS)
  )
  fixed_line(spec2)
}

build_harvest <- function(month, day, HARVEFF = 1.0, husc = 0) {
  spec <- common_prefix_specs(month, day, 7, husc)
  spec2 <- rbind(spec, data.frame(name="HARVEFF", col=32, width=12,
                                  fmt="%12.5f", val=HARVEFF))
  fixed_line(spec2)
}

build_kill <- function(month, day, husc = 0) {
  spec <- common_prefix_specs(month, day, 8, husc)
  fixed_line(spec)
}

build_year_end <- function(month = 12, day = 31, husc = 0) {
  spec <- common_prefix_specs(month, day, 0, husc)
  fixed_line(spec)
}

## ---------- ONE-YEAR SCHEDULES ---------------------------------------------

# HAY one-year schedule: same as baseline Script B
hay_schedule_one_year <- function() {
  c(
    build_planting  (5, 1,  PLANT_ID=4, HEAT_UNITS=1200.0),
    build_fertilizer(5, 2,  FERT_ID=54, FERT_KG="168.127",  FRT_SURFACE=1.00),
    build_harvest   (6, 1,  HARVEFF=1.0),
    build_harvest   (7, 15, HARVEFF=1.0),
    build_fertilizer(7, 16, FERT_ID=53, FERT_KG="842.0",    FRT_SURFACE=1.00),
    build_harvest   (8, 30, HARVEFF=1.0),
    build_fertilizer(9, 1,  FERT_ID=53, FERT_KG="842.0",    FRT_SURFACE=1.00),
    build_year_end  (12, 31, husc = 0)
  )
}

# CORN one-year schedule with winter rye (S2)
corn_schedule_one_year <- function() {
  c(
    # New: kill rye in early spring (from previous winter)
    build_kill      (4, 15),
    
    # Corn growing season (same as baseline)
    build_tillage   (5, 10, TILL_ID=61),
    build_fertilizer(5, 15, FERT_ID=54, FERT_KG="112.085",  FRT_SURFACE=1.00),
    build_planting  (5, 15, PLANT_ID=4, HEAT_UNITS=1800.0),   # corn
    build_fertilizer(7, 10, FERT_ID=54, FERT_KG="266.302",  FRT_SURFACE=1.00),
    build_harvest   (10, 1, HARVEFF=0.01),
    build_kill      (10, 1),
    build_fertilizer(10,10, FERT_ID=53, FERT_KG="2806.200", FRT_SURFACE=1.00),
    build_tillage   (10,15, TILL_ID=57),
    
    # New: plant winter rye after corn + fall manure / tillage
    build_planting  (10,20, PLANT_ID = RYE_PLANT_ID,
                     HEAT_UNITS = RYE_HEAT_UNITS),
    
    # Year-end marker
    build_year_end  (12, 31, husc = 0)
  )
}

.schedule_map <- list(hay = hay_schedule_one_year,
                      corn = corn_schedule_one_year)

build_rotation_schedule <- function(rotation_vec) {
  stopifnot(length(rotation_vec) > 0, !is.null(names(rotation_vec)))
  lines <- character(0); total_years <- 0L
  for (k in seq_along(rotation_vec)) {
    crop <- names(rotation_vec)[k]; yrs <- as.integer(rotation_vec[[k]])
    if (!crop %in% names(.schedule_map)) stop("Unknown crop key: ", crop)
    one_year <- .schedule_map[[crop]]()
    for (i in seq_len(yrs)) lines <- c(lines, one_year)
    total_years <- total_years + yrs
  }
  attr(lines, "nrot") <- total_years
  lines
}

## ---------- HEADER & SCHEDULE UTILITIES ------------------------------------

mgt_set_nrot <- function(lines, nrot) {
  ix <- grep("\\|\\s*NROT\\b", lines, perl = TRUE)
  if (!length(ix)) stop("NROT line not found.")
  tgt <- ix[1]
  lines[tgt] <- sub("^\\s*[-+]?[0-9]*\\.?\\d+",
                    as.character(as.integer(nrot)), lines[tgt])
  lines
}

replace_operation_schedule <- function(lines, new_schedule_lines) {
  start <- grep("^\\s*Operation\\s+Schedule:", lines)
  if (!length(start)) stop("'Operation Schedule:' line not found.")
  start <- start[1]
  after <- start + 1L
  while (after <= length(lines) &&
         nzchar(trimws(lines[after])) &&
         !grepl("^\\s*[A-Za-z].*:\\s*$", lines[after])) {
    after <- after + 1L
  }
  if (after > length(lines)) {
    c(lines[1:start], new_schedule_lines)
  } else {
    c(lines[1:start], new_schedule_lines, lines[after:length(lines)])
  }
}

.parse_field <- function(line, start, end) {
  as.integer(gsub("\\s+", "", substr(line, start, end)))
}

validate_ops <- function(op_lines, total_cols = TOTAL_COLS) {
  ok <- TRUE; problems <- list()
  for (i in seq_along(op_lines)) {
    L <- op_lines[[i]]
    if (nchar(L, "bytes") != total_cols) {
      ok <- FALSE; problems[[length(problems)+1]] <-
        paste0("Line ", i, ": width=", nchar(L, "bytes"))
      next
    }
    mm <- .parse_field(L, 2, 3)
    dd <- .parse_field(L, 5, 6)
    if (is.na(mm) || mm < 1 || mm > 12) {
      ok <- FALSE; problems[[length(problems)+1]] <- paste0("Line ", i, ": bad MONTH=", mm)
    }
    if (is.na(dd) || dd < 1 || dd > 31) {
      ok <- FALSE; problems[[length(problems)+1]] <- paste0("Line ", i, ": bad DAY=", dd)
    }
    op <- .parse_field(L, 17, 18)
    if (is.na(op) || !(op %in% c(0,1,3,6,7,8,17))) {
      ok <- FALSE; problems[[length(problems)+1]] <- paste0("Line ", i, ": bad MGT_OP=", op)
    }
  }
  list(ok = ok, problems = problems)
}

count_year_ends <- function(op_lines) {
  sum(vapply(op_lines,
             function(L) .parse_field(L, 17, 18) == 0L,
             logical(1)))
}

update_mgt_file <- function(mgt_path, schedule_lines, nrot) {
  chk <- validate_ops(schedule_lines, total_cols = TOTAL_COLS)
  if (!chk$ok) {
    stop(paste(c("Validation failed:", unlist(chk$problems)), collapse = "\n"))
  }
  if (count_year_ends(schedule_lines) != nrot) {
    stop("NROT mismatch between rotation years and MGT_OP=0 count in schedule.")
  }
  
  old <- readLines(mgt_path, warn = FALSE)
  new <- old
  new <- mgt_set_nrot(new, nrot)
  new <- replace_operation_schedule(new, schedule_lines)
  
  if (!identical(old, new)) {
    bak <- paste0(mgt_path, ".S2_WinterRye.bak")
    writeLines(old, bak, useBytes = TRUE)
    writeLines(new, mgt_path, useBytes = TRUE)
  }
  invisible(TRUE)
}

update_mgt_file_with_rotation <- function(mgt_path, rotation_vec) {
  sched <- build_rotation_schedule(rotation_vec)
  nrot  <- attr(sched, "nrot")
  update_mgt_file(mgt_path, sched, nrot)
}

## ---------- PARSE HRU_ID FROM .MGT ----------------------------------------

parse_hru_id_from_mgt <- function(fp) {
  first_line <- readr::read_lines(fp, n_max = 1)
  hru_token  <- stringr::str_extract(first_line, "HRU:\\s*\\d+")
  if (is.na(hru_token)) return(NA_integer_)
  as.integer(stringr::str_extract(hru_token, "\\d+"))
}

## ---------- APPLY BMP TO SCENARIO .MGT FILES -------------------------------

mgt_files <- list.files(scenario_dir,
                        pattern = "^[^.].*\\.mgt$",
                        full.names = TRUE,
                        recursive = TRUE)

count_hay  <- 0L
count_corn <- 0L
count_skip <- 0L

for (fp in mgt_files) {
  hru_id <- parse_hru_id_from_mgt(fp)
  if (is.na(hru_id)) {
    count_skip <- count_skip + 1L
    next
  }
  
  if (hru_id %in% hay_hrus) {
    # Hay cohort: same rotation as baseline, no rye
    update_mgt_file_with_rotation(fp, rotation_for_hay_cohort)
    count_hay <- count_hay + 1L
    
  } else if (hru_id %in% corn_hrus) {
    # Corn-from-hay cohort: corn years with winter rye cover crop
    update_mgt_file_with_rotation(fp, rotation_for_corn_cohort)
    count_corn <- count_corn + 1L
    
  } else {
    count_skip <- count_skip + 1L
  }
}

cat("\nS2_WinterRye summary:",
    "\n  Hay cohort .mgt edited:          ", count_hay,
    "\n  CornFromHay cohort .mgt edited:  ", count_corn,
    "\n  .mgt files skipped (other/NA):   ", count_skip,
    "\n  Scenario directory:              ", scenario_dir, "\n")


###############################
### RUN SWAT FOR covercrop_WinterRye
###############################

pacman::p_load(
  SWATmodel, dplyr, EcoHydRology, base, topmodel, utils,
  lubridate, stringr, diffobj, tidyr, rnoaa, readr, ggplot2
)

run_swat <- function(swat_exe  = "~/new_swat/rev688_64rel_linux",
                     work_dir  = scenario_dir) {
  
  swat_exe <- path.expand(swat_exe)
  work_dir <- path.expand(work_dir)
  
  if (!file.exists(swat_exe)) stop("SWAT executable not found: ", swat_exe)
  if (!dir.exists(work_dir))  stop("Working dir not found: ", work_dir)
  
  setwd(work_dir)
  
  message("Cleaning old output files …")
  old_out <- list.files(pattern = "output\\.")
  if (length(old_out)) file.remove(old_out)
  
  message("Running SWAT in S2_WinterRye …")
  system(shQuote(swat_exe), intern = FALSE)
  
  new_out <- list.files(pattern = "output\\.")
  if (length(new_out)) {
    message("SWAT run completed ✔")
    return(new_out)
  } else {
    stop("SWAT produced no output files in scenario_dir.")
  }
}

# ── run it ───────────────────────────────────────────────────────────────────
output_files <- run_swat()
cat("Generated output files in S2_WinterRye:\n"); print(output_files)


#########################################
### EVENT-BASED TOTAL P (kg) + PLOT  ####
#########################################

library(dplyr)
library(ggplot2)
library(EcoHydRology)

# Your local R tools folder for readSWAT_3.R
myhomedir <- Sys.getenv("HOME")
basedir   <- myhomedir
codedir   <- paste0(basedir, "/swat_LOC/R")

setwd(scenario_dir)

# readSWAT helper
source(file.path(codedir, "readSWAT_3.R"))
save(readSWAT, file = "readSWAT.R")

# 1. Read reach output and keep RCH 3
load("readSWAT.R")
outdata  <- readSWAT("rch", ".")
rch_data <- subset(outdata, RCH == 3)
rch_data$Date <- rch_data$mdate

# 2. Read Events with observed event TP (kg)
#    (same Events.csv you used for baseline)
Events <- read.csv("Events.csv")
Events$start_date <- as.Date(Events$start_date, "%m/%d/%Y")
Events$end_date   <- as.Date(Events$end_date,   "%m/%d/%Y")

# 3. Aggregate simulated TP (TOT_Pkg) per event
sim_P <- numeric(nrow(Events))
for (i in seq_len(nrow(Events))) {
  ev <- subset(rch_data,
               Date >= Events$start_date[i] &
                 Date <= Events$end_date[i])
  sim_P[i] <- sum(ev$TOT_Pkg, na.rm = TRUE)
}
Events$Total_P_simulated <- sim_P

# If Events already has observed Tot_P (kg) column, we just reuse it


#####################
### PLOT EVENT TP ###
#####################

# title_text <- if (!is.na(NSE_P)) {
#   paste0("S2 Winter Rye – Event Total P (kg), NSE = ",
#          round(as.numeric(NSE_P), 3))
# } else {
#   "S2 Winter Rye – Event Total P (kg)"
# }

ggplot(Events, aes(x = end_date)) +
  
  # Lines (or change to geom_point if you prefer points)
  geom_line(aes(y = Total_P_simulated, color = "Simulated"), size = 1.6, alpha = 0.9) +
  geom_line(aes(y = Tot_P,              color = "Observed"), size = 1.6, alpha = 0.9) +
  
  labs(
    x     = "",
    y     = "Total P (kg)",
    color = ""
  ) +
  scale_color_manual(
    values = c("Simulated" = "magenta", "Observed" = "orange")
  ) +
  theme_minimal(base_size = 14) +
  theme(
    plot.title  = element_text(size = 15, hjust = 0.5),
    axis.title  = element_text(size = 14),
    axis.text   = element_text(size = 12),
    panel.border = element_rect(color = "black", fill = NA, size = 1),
    plot.margin = margin(t = 5, r = 25, b = 5, l = 5, unit = "pt")
  )
